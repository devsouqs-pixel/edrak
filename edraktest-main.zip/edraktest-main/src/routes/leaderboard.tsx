import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { collection, onSnapshot, query, orderBy, limit, where } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { GRADES, getRank } from "@/lib/constants";
import { Trophy, Medal } from "lucide-react";

export const Route = createFileRoute("/leaderboard")({
  component: LeaderboardPage,
  head: () => ({ meta: [{ title: "لوحة المتصدرين — إدراك" }] }),
});

interface U { uid: string; displayName: string; photoURL: string; grade: string; points: number; }

function LeaderboardPage() {
  const [users, setUsers] = useState<U[]>([]);
  const [grade, setGrade] = useState<string>(GRADES[0]);

  useEffect(() => {
    const q = query(collection(db, "users"), orderBy("points", "desc"), limit(100));
    return onSnapshot(q, (snap) => setUsers(snap.docs.map((d) => ({ uid: d.id, ...(d.data() as any) }))));
  }, []);

  const filtered = users.filter((u) => u.grade === grade);

  return (
    <div className="mx-auto max-w-3xl px-4 py-6">
      <div className="mb-6 flex items-center gap-3">
        <Trophy className="h-8 w-8 text-amber-500" />
        <div>
          <h1 className="text-3xl font-black">لوحة المتصدرين</h1>
          <p className="text-sm text-muted-foreground">أفضل الطلاب في إدراك</p>
        </div>
      </div>

      <Tabs defaultValue="global">
        <TabsList className="mb-4 grid w-full grid-cols-2">
          <TabsTrigger value="global">عام</TabsTrigger>
          <TabsTrigger value="grade">حسب الصف</TabsTrigger>
        </TabsList>

        <TabsContent value="global"><Board users={users} /></TabsContent>
        <TabsContent value="grade">
          <div className="mb-3 flex flex-wrap gap-2">
            {GRADES.map((g) => (
              <button key={g} onClick={() => setGrade(g)}
                className={`rounded-full border px-3 py-1.5 text-xs ${grade === g ? "border-primary bg-primary text-primary-foreground" : ""}`}>
                {g}
              </button>
            ))}
          </div>
          <Board users={filtered} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function Board({ users }: { users: U[] }) {
  if (users.length === 0) return <div className="rounded-2xl border border-dashed py-12 text-center text-sm text-muted-foreground">لا توجد بيانات</div>;
  return (
    <div className="space-y-2">
      {users.map((u, i) => {
        const rank = getRank(u.points || 0);
        const colors = ["text-amber-500", "text-slate-400", "text-orange-600"];
        return (
          <div key={u.uid} className="flex items-center gap-3 rounded-2xl border bg-card p-3 shadow-soft">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted">
              {i < 3 ? <Medal className={`h-5 w-5 ${colors[i]}`} /> : <span className="text-sm font-bold text-muted-foreground">#{i + 1}</span>}
            </div>
            <Avatar><AvatarImage src={u.photoURL} /><AvatarFallback>{u.displayName?.[0]}</AvatarFallback></Avatar>
            <div className="flex-1 min-w-0">
              <div className="truncate font-semibold">{u.displayName}</div>
              <div className="flex items-center gap-2 text-xs">
                <span style={{ color: rank.color }} className="font-semibold">{rank.name}</span>
                {u.grade && <span className="text-muted-foreground">• {u.grade}</span>}
              </div>
            </div>
            <div className="text-left">
              <div className="text-xl font-black text-gradient">{u.points || 0}</div>
              <div className="text-xs text-muted-foreground">نقطة</div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
