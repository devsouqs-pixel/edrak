import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/contexts/AuthContext";
import { GRADES, SUBJECTS_BY_GRADE } from "@/lib/constants";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Loader2, Sparkles } from "lucide-react";

export const Route = createFileRoute("/rooms/new")({
  component: NewRoomPage,
  head: () => ({ meta: [{ title: "إنشاء جولة — إدراك" }] }),
});

function NewRoomPage() {
  const { user, userData } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [grade, setGrade] = useState("");
  const [subject, setSubject] = useState("");
  const [mode, setMode] = useState<"duration" | "target">("duration");
  const [duration, setDuration] = useState(45);
  const [targetTime, setTargetTime] = useState("");
  const [breakOn, setBreakOn] = useState(false);
  const [breakDuration, setBreakDuration] = useState(5);
  const [isPrivate, setIsPrivate] = useState(false);
  const [code, setCode] = useState("");
  const [loading, setLoading] = useState(false);

  const subjects = grade ? SUBJECTS_BY_GRADE[grade] || [] : [];

  const submit = async () => {
    if (!user || !userData) return;
    if (!name.trim() || !grade || !subject) { toast.error("املأ كل الحقول الإلزامية"); return; }
    if (isPrivate && !/^\d{4}$/.test(code)) { toast.error("الكود يجب أن يكون 4 أرقام"); return; }
    if (mode === "target" && !targetTime) { toast.error("اختر الوقت المستهدف"); return; }

    let computedDuration = duration;
    let endsAt = Date.now() + duration * 60_000;
    if (mode === "target") {
      const [h, m] = targetTime.split(":").map(Number);
      const target = new Date(); target.setHours(h, m, 0, 0);
      if (target.getTime() <= Date.now()) target.setDate(target.getDate() + 1);
      endsAt = target.getTime();
      computedDuration = Math.round((endsAt - Date.now()) / 60_000);
    }

    setLoading(true);
    try {
      const ref = await addDoc(collection(db, "rooms"), {
        name: name.trim(), grade, subject,
        ownerId: user.uid, ownerName: userData.displayName,
        mode, duration: computedDuration, endsAt,
        breakOn, breakDuration,
        isPrivate, code: isPrivate ? code : null,
        memberCount: 0, members: [],
        chatDisabled: false, status: "waiting",
        createdAt: serverTimestamp(),
      });
      toast.success("تم إنشاء الجولة!");
      navigate({ to: "/rooms/$roomId", params: { roomId: ref.id } });
    } catch (e: any) {
      toast.error("فشل الإنشاء", { description: e?.message });
    } finally { setLoading(false); }
  };

  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <div className="mb-6 flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl gradient-primary"><Sparkles className="h-5 w-5 text-white" /></div>
        <div>
          <h1 className="text-2xl font-black">جولة دراسية جديدة</h1>
          <p className="text-sm text-muted-foreground">صمّم جلستك المثالية</p>
        </div>
      </div>

      <div className="space-y-5 rounded-2xl border bg-card p-6 shadow-soft">
        <div>
          <Label>اسم الجولة *</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="مثلاً: مراجعة فيزياء" className="mt-1.5" />
        </div>

        <div>
          <Label>الصف الدراسي *</Label>
          <div className="mt-2 flex flex-wrap gap-2">
            {GRADES.map((g) => (
              <button key={g} type="button" onClick={() => { setGrade(g); setSubject(""); }}
                className={`rounded-full border px-3 py-1.5 text-sm transition ${grade === g ? "border-primary bg-primary text-primary-foreground" : "hover:bg-accent"}`}>
                {g}
              </button>
            ))}
          </div>
        </div>

        {grade && (
          <div>
            <Label>المادة *</Label>
            <div className="mt-2 flex flex-wrap gap-2">
              {subjects.map((s) => (
                <button key={s} type="button" onClick={() => setSubject(s)}
                  className={`rounded-full border px-3 py-1.5 text-sm transition ${subject === s ? "border-primary bg-primary text-primary-foreground" : "hover:bg-accent"}`}>
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        <div>
          <Label>طريقة المؤقت *</Label>
          <div className="mt-2 grid grid-cols-2 gap-2">
            <button type="button" onClick={() => setMode("duration")} className={`rounded-xl border p-3 text-sm font-semibold ${mode === "duration" ? "border-primary bg-accent" : ""}`}>
              تحديد مدة
            </button>
            <button type="button" onClick={() => setMode("target")} className={`rounded-xl border p-3 text-sm font-semibold ${mode === "target" ? "border-primary bg-accent" : ""}`}>
              وقت مستهدف
            </button>
          </div>
        </div>

        {mode === "duration" ? (
          <div>
            <Label>المدة بالدقائق</Label>
            <Input type="number" min={5} max={300} value={duration} onChange={(e) => setDuration(+e.target.value)} className="mt-1.5" />
          </div>
        ) : (
          <div>
            <Label>الوقت المستهدف (ساعة:دقيقة)</Label>
            <Input type="time" value={targetTime} onChange={(e) => setTargetTime(e.target.value)} className="mt-1.5" />
          </div>
        )}

        <div className="flex items-center justify-between rounded-xl border p-3">
          <div><Label>تفعيل الاستراحة</Label><p className="text-xs text-muted-foreground">استراحة قصيرة بمنتصف الجلسة</p></div>
          <Switch checked={breakOn} onCheckedChange={setBreakOn} />
        </div>
        {breakOn && (<div><Label>مدة الاستراحة (دقائق)</Label><Input type="number" min={1} max={30} value={breakDuration} onChange={(e) => setBreakDuration(+e.target.value)} className="mt-1.5" /></div>)}

        <div className="flex items-center justify-between rounded-xl border p-3">
          <div><Label>جولة خاصة</Label><p className="text-xs text-muted-foreground">دخول بكود سري</p></div>
          <Switch checked={isPrivate} onCheckedChange={setIsPrivate} />
        </div>
        {isPrivate && (
          <div>
            <Label>كود الدخول (4 أرقام)</Label>
            <Input value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 4))} placeholder="0000" className="mt-1.5 text-center text-xl tracking-widest" maxLength={4} />
          </div>
        )}

        <Button onClick={submit} disabled={loading} size="lg" className="w-full">
          {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : "إنشاء الجولة"}
        </Button>
      </div>
    </div>
  );
}
