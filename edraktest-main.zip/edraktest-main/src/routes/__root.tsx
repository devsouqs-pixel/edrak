import { Outlet, Link, createRootRoute, HeadContent, Scripts, useRouterState } from "@tanstack/react-router";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { Toaster } from "@/components/ui/sonner";
import { AppShell } from "@/components/AppShell";
import { LoginScreen } from "@/components/LoginScreen";
import { MaintenanceGate, DuaPopup } from "@/components/SiteWrappers";
import { Loader2 } from "lucide-react";
import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-gradient">404</h1>
        <h2 className="mt-4 text-xl font-semibold">الصفحة غير موجودة</h2>
        <Link to="/" className="mt-6 inline-flex rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">
          العودة للرئيسية
        </Link>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "إدراك — منصة الدراسة الجماعية" },
      { name: "description", content: "ادرس مع أصدقائك، انضم لجولات دراسية، وحقق أهدافك التعليمية" },
      { property: "og:title", content: "إدراك — منصة الدراسة الجماعية" },
      { name: "twitter:title", content: "إدراك — منصة الدراسة الجماعية" },
      { property: "og:description", content: "ادرس مع أصدقائك، انضم لجولات دراسية، وحقق أهدافك التعليمية" },
      { name: "twitter:description", content: "ادرس مع أصدقائك، انضم لجولات دراسية، وحقق أهدافك التعليمية" },
      { property: "og:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/8abb92d4-4f46-484c-a9d1-31de641a8a24/id-preview-1d1237e2--28ceedd0-3e71-4b0e-96d2-3953ecd480b2.lovable.app-1777409262379.png" },
      { name: "twitter:image", content: "https://pub-bb2e103a32db4e198524a2e9ed8f35b4.r2.dev/8abb92d4-4f46-484c-a9d1-31de641a8a24/id-preview-1d1237e2--28ceedd0-3e71-4b0e-96d2-3953ecd480b2.lovable.app-1777409262379.png" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:type", content: "website" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;900&display=swap" },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <head><HeadContent /></head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AuthGate />
        <Toaster richColors position="top-center" />
      </AuthProvider>
    </ThemeProvider>
  );
}

function AuthGate() {
  const { user, loading } = useAuth();
  const path = useRouterState({ select: (s) => s.location.pathname });

  // admin route bypass
  if (path.startsWith("/admin")) return <Outlet />;

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  if (!user) return <LoginScreen />;
  return (
    <MaintenanceGate>
      <AppShell><Outlet /></AppShell>
      <DuaPopup />
    </MaintenanceGate>
  );
}
