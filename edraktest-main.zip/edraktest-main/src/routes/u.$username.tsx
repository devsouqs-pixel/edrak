import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { findUserByUsername } from "@/lib/follow";
import { collection, onSnapshot, orderBy, query, where, doc, getDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { FollowButton } from "@/components/FollowButton";
import { getRank } from "@/lib/constants";
import { Loader2, ArrowRight } from "lucide-react";

export const Route = createFileRoute("/u/$username")({
  component: PublicProfile,
  head: () => ({ meta: [{ title: "بروفايل — إدراك" }] }),
});

function PublicProfile() {
  const { username } = Route.useParams();
  const [u, setU] = useState<any>(null);
  const [posts, setPosts] = useState<any[]>([]);
  const [followers, setFollowers] = useState<any[]>([]);
  const [following, setFollowing] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { findUserByUsername(username).then((x) => { setU(x); setLoading(false); }); }, [username]);

  useEffect(() => {
    if (!u?.uid) return;
    const q = query(collection(db, "posts"), where("uid", "==", u.uid), orderBy("createdAt", "desc"));
    const u1 = onSnapshot(q, (s) => setPosts(s.docs.map((d) => ({ id: d.id, ...d.data() }))));
    const u2 = onSnapshot(collection(db, "users", u.uid, "followers"), async (s) => {
      const items = await Promise.all(s.docs.map(async (d) => {
        const ud = await getDoc(doc(db, "users", d.id));
        return ud.exists() ? { uid: d.id, ...ud.data() } : null;
      }));
      setFollowers(items.filter(Boolean) as any);
    });
    const u3 = onSnapshot(collection(db, "users", u.uid, "following"), async (s) => {
      const items = await Promise.all(s.docs.map(async (d) => {
        const ud = await getDoc(doc(db, "users", d.id));
        return ud.exists() ? { uid: d.id, ...ud.data() } : null;
      }));
      setFollowing(items.filter(Boolean) as any);
    });
    return () => { u1(); u2(); u3(); };
  }, [u?.uid]);

  if (loading) return <div className="flex min-h-[40vh] items-center justify-center"><Loader2 className="h-6 w-6 animate-spin" /></div>;
  if (!u) return (
    <div className="mx-auto max-w-md py-16 text-center">
      <h1 className="text-2xl font-black">المستخدم غير موجود</h1>
      <Button asChild variant="outline" className="mt-6"><Link to="/">العودة</Link></Button>
    </div>
  );
  const rank = getRank(u.points || 0);

  return (
    <div className="mx-auto max-w-3xl px-4 py-6">
      <div className="overflow-hidden rounded-3xl border bg-card shadow-soft">
        <div className="h-32 gradient-primary" />
        <div className="px-6 pb-6">
          <div className="flex items-end justify-between">
            <Avatar className="-mt-12 h-24 w-24 border-4 border-card">
              <AvatarImage src={u.photoURL} />
              <AvatarFallback>{u.displayName?.[0]}</AvatarFallback>
            </Avatar>
            <FollowButton targetUid={u.uid} />
          </div>
          <h1 className="mt-3 text-2xl font-black">{u.displayName}</h1>
          <p className="text-sm text-muted-foreground">@{u.username}</p>
          <div className="mt-2 inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold" style={{ backgroundColor: `${rank.color}22`, color: rank.color }}>
            {rank.name}
          </div>
          {u.grade && <p className="mt-2 text-sm text-muted-foreground">الصف: {u.grade}</p>}
          {u.bio && <p className="mt-3 whitespace-pre-wrap text-sm">{u.bio}</p>}

          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="النقاط" value={u.points || 0} />
            <Stat label="الجولات" value={u.completedRounds || 0} />
            <Stat label="ساعات" value={Math.round((u.studyMinutes || 0) / 60)} />
            <Stat label="Streak" value={u.streak || 0} />
          </div>
          <div className="mt-3 flex justify-around rounded-xl border bg-muted/30 p-3 text-center text-sm">
            <div><div className="font-black">{followers.length}</div><div className="text-xs text-muted-foreground">متابِعون</div></div>
            <div><div className="font-black">{following.length}</div><div className="text-xs text-muted-foreground">يتابع</div></div>
            <div><div className="font-black">{posts.length}</div><div className="text-xs text-muted-foreground">منشور</div></div>
          </div>
        </div>
      </div>

      {u.privacy === "private" ? (
        <div className="mt-6 rounded-2xl border border-dashed bg-card/50 py-12 text-center text-sm text-muted-foreground">
          هذا الحساب خاص
        </div>
      ) : (
        <Tabs defaultValue="posts" className="mt-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="posts">المنشورات</TabsTrigger>
            <TabsTrigger value="followers">المتابِعون</TabsTrigger>
            <TabsTrigger value="following">يتابع</TabsTrigger>
          </TabsList>
          <TabsContent value="posts" className="mt-4 space-y-3">
            {posts.length === 0 && <Empty text="لا منشورات" />}
            {posts.map((p) => (
              <div key={p.id} className="rounded-2xl border bg-card p-4 shadow-soft">
                <p className="whitespace-pre-wrap text-sm">{p.text}</p>
              </div>
            ))}
          </TabsContent>
          <TabsContent value="followers" className="mt-4"><UserList items={followers} /></TabsContent>
          <TabsContent value="following" className="mt-4"><UserList items={following} /></TabsContent>
        </Tabs>
      )}

      <div className="mt-6 text-center">
        <Button asChild variant="ghost" size="sm" className="gap-2"><Link to="/"><ArrowRight className="h-4 w-4" /> الرئيسية</Link></Button>
      </div>
    </div>
  );
}
function Stat({ label, value }: { label: string; value: number }) {
  return <div className="rounded-xl border bg-muted/30 p-3 text-center"><div className="text-xl font-black text-gradient">{value}</div><div className="text-xs text-muted-foreground">{label}</div></div>;
}
function Empty({ text }: { text: string }) {
  return <div className="rounded-2xl border border-dashed bg-card/50 py-12 text-center text-sm text-muted-foreground">{text}</div>;
}
function UserList({ items }: { items: any[] }) {
  if (items.length === 0) return <Empty text="لا يوجد" />;
  return (
    <div className="space-y-2">
      {items.map((u) => (
        <Link key={u.uid} to="/u/$username" params={{ username: u.username }} className="flex items-center gap-3 rounded-xl border bg-card p-3 hover:bg-muted/50">
          <Avatar className="h-10 w-10"><AvatarImage src={u.photoURL} /><AvatarFallback>{u.displayName?.[0]}</AvatarFallback></Avatar>
          <div><div className="text-sm font-semibold">{u.displayName}</div><div className="text-xs text-muted-foreground">@{u.username}</div></div>
        </Link>
      ))}
    </div>
  );
}
