import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { collection, deleteDoc, doc, getDocs, limit, orderBy, query, setDoc, updateDoc, increment } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Loader2, Lock, LogOut, Trash2, Search, Shield, Users, MessageSquare, Home as HomeIcon, FileText, Wrench, Plus, Minus } from "lucide-react";
import { toast } from "sonner";

const ADMIN_CODE = "2042009";
const STORAGE_KEY = "edrak_admin_session";

export const Route = createFileRoute("/admin")({
  component: AdminPage,
  head: () => ({ meta: [{ title: "لوحة الإدارة — إدراك" }] }),
});

function AdminPage() {
  const [authed, setAuthed] = useState(false);
  const [code, setCode] = useState("");

  useEffect(() => {
    if (typeof window !== "undefined" && sessionStorage.getItem(STORAGE_KEY) === "ok") setAuthed(true);
  }, []);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (code === ADMIN_CODE) {
      sessionStorage.setItem(STORAGE_KEY, "ok");
      setAuthed(true);
      toast.success("مرحباً بك في لوحة الإدارة");
    } else {
      toast.error("كود خاطئ");
    }
  };

  const logout = () => {
    sessionStorage.removeItem(STORAGE_KEY);
    setAuthed(false);
    setCode("");
  };

  if (!authed) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background p-4" dir="rtl">
        <form onSubmit={submit} className="w-full max-w-sm space-y-4 rounded-2xl border bg-card p-6 shadow-soft">
          <div className="flex flex-col items-center text-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl gradient-primary shadow-glow">
              <Shield className="h-7 w-7 text-white" />
            </div>
            <h1 className="mt-3 text-xl font-black">لوحة إدارة إدراك</h1>
            <p className="text-xs text-muted-foreground">مدخل خاص بالمسؤولين فقط</p>
          </div>
          <div>
            <label className="text-sm font-medium">كود الدخول</label>
            <div className="relative mt-1">
              <Lock className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input type="password" value={code} onChange={(e) => setCode(e.target.value)} className="pr-9" placeholder="••••••••" autoFocus />
            </div>
          </div>
          <Button type="submit" className="w-full">دخول</Button>
        </form>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      <header className="sticky top-0 z-30 flex items-center justify-between border-b bg-background/80 px-4 py-3 backdrop-blur-xl">
        <div className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-primary" />
          <h1 className="text-lg font-black">لوحة الإدارة</h1>
        </div>
        <Button variant="ghost" size="sm" onClick={logout}>
          <LogOut className="ml-1 h-4 w-4" /> خروج
        </Button>
      </header>

      <div className="mx-auto max-w-6xl p-4">
        <Tabs defaultValue="users" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="users"><Users className="ml-1 h-4 w-4" />المستخدمون</TabsTrigger>
            <TabsTrigger value="rooms"><HomeIcon className="ml-1 h-4 w-4" />الغرف</TabsTrigger>
            <TabsTrigger value="posts"><MessageSquare className="ml-1 h-4 w-4" />المنشورات</TabsTrigger>
            <TabsTrigger value="files"><FileText className="ml-1 h-4 w-4" />الملفات</TabsTrigger>
            <TabsTrigger value="site"><Wrench className="ml-1 h-4 w-4" />الموقع</TabsTrigger>
          </TabsList>
          <TabsContent value="users" className="mt-4"><UsersTab /></TabsContent>
          <TabsContent value="rooms" className="mt-4"><GenericList col="rooms" titleField="name" subField="subject" /></TabsContent>
          <TabsContent value="posts" className="mt-4"><GenericList col="posts" titleField="content" subField="authorName" /></TabsContent>
          <TabsContent value="files" className="mt-4"><GenericList col="files" titleField="title" subField="grade" /></TabsContent>
          <TabsContent value="site" className="mt-4"><SiteTab /></TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function UsersTab() {
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  const load = async () => {
    setLoading(true);
    try {
      const snap = await getDocs(query(collection(db, "users"), orderBy("points", "desc"), limit(200)));
      setUsers(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    } catch (e: any) { toast.error("فشل التحميل", { description: e?.message }); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, []);

  const filtered = users.filter((u) =>
    !search || (u.displayName || "").includes(search) || (u.username || "").includes(search) || (u.email || "").includes(search)
  );

  const adjustPoints = async (uid: string, delta: number) => {
    try {
      await updateDoc(doc(db, "users", uid), { points: increment(delta) });
      setUsers((prev) => prev.map((u) => u.id === uid ? { ...u, points: (u.points || 0) + delta } : u));
      toast.success(`تم ${delta > 0 ? "إضافة" : "خصم"} ${Math.abs(delta)} نقطة`);
    } catch (e: any) { toast.error(e?.message); }
  };

  const setAdmin = async (uid: string, val: boolean) => {
    try {
      await updateDoc(doc(db, "users", uid), { isAdmin: val });
      setUsers((prev) => prev.map((u) => u.id === uid ? { ...u, isAdmin: val } : u));
      toast.success(val ? "تم تعيين كأدمن" : "تم إزالة الأدمن");
    } catch (e: any) { toast.error(e?.message); }
  };

  const del = async (uid: string) => {
    if (!confirm("حذف هذا المستخدم من قاعدة البيانات؟")) return;
    try {
      await deleteDoc(doc(db, "users", uid));
      setUsers((prev) => prev.filter((u) => u.id !== uid));
      toast.success("تم الحذف");
    } catch (e: any) { toast.error(e?.message); }
  };

  if (loading) return <Center><Loader2 className="h-6 w-6 animate-spin text-primary" /></Center>;

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input placeholder="بحث بالاسم أو البريد..." value={search} onChange={(e) => setSearch(e.target.value)} className="pr-9" />
      </div>
      <div className="text-sm text-muted-foreground">إجمالي: {filtered.length}</div>
      <div className="space-y-2">
        {filtered.map((u) => (
          <div key={u.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border bg-card p-3">
            <div className="flex items-center gap-3 min-w-0">
              <img src={u.photoURL || ""} alt="" className="h-10 w-10 rounded-full bg-muted object-cover" />
              <div className="min-w-0">
                <div className="truncate font-bold">{u.displayName} {u.isAdmin && <span className="text-xs text-primary">(أدمن)</span>}</div>
                <div className="truncate text-xs text-muted-foreground">@{u.username} • {u.email}</div>
                <div className="text-xs">⭐ {u.points || 0} نقطة • {u.completedRounds || 0} جولة</div>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              <Button size="icon" variant="outline" onClick={() => adjustPoints(u.id, 10)}><Plus className="h-3 w-3" /></Button>
              <Button size="icon" variant="outline" onClick={() => adjustPoints(u.id, -10)}><Minus className="h-3 w-3" /></Button>
              <div className="flex items-center gap-1 text-xs">
                <Switch checked={!!u.isAdmin} onCheckedChange={(v) => setAdmin(u.id, v)} />
                أدمن
              </div>
              <Button size="icon" variant="destructive" onClick={() => del(u.id)}><Trash2 className="h-4 w-4" /></Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function GenericList({ col, titleField, subField }: { col: string; titleField: string; subField: string }) {
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  const load = async () => {
    setLoading(true);
    try {
      const snap = await getDocs(query(collection(db, col), limit(200)));
      setItems(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    } catch (e: any) { toast.error("فشل التحميل", { description: e?.message }); }
    finally { setLoading(false); }
  };
  useEffect(() => { load(); }, [col]);

  const del = async (id: string) => {
    if (!confirm("حذف نهائي؟")) return;
    try {
      await deleteDoc(doc(db, col, id));
      setItems((prev) => prev.filter((x) => x.id !== id));
      toast.success("تم الحذف");
    } catch (e: any) { toast.error(e?.message); }
  };

  const filtered = items.filter((x) =>
    !search || String(x[titleField] || "").includes(search) || String(x[subField] || "").includes(search)
  );

  if (loading) return <Center><Loader2 className="h-6 w-6 animate-spin text-primary" /></Center>;

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input placeholder="بحث..." value={search} onChange={(e) => setSearch(e.target.value)} className="pr-9" />
      </div>
      <div className="text-sm text-muted-foreground">إجمالي: {filtered.length}</div>
      <div className="space-y-2">
        {filtered.map((x) => (
          <div key={x.id} className="flex items-center justify-between gap-3 rounded-xl border bg-card p-3">
            <div className="min-w-0">
              <div className="truncate font-bold">{String(x[titleField] || "—").slice(0, 100)}</div>
              <div className="truncate text-xs text-muted-foreground">{String(x[subField] || "")} • ID: {x.id}</div>
            </div>
            <Button size="icon" variant="destructive" onClick={() => del(x.id)}><Trash2 className="h-4 w-4" /></Button>
          </div>
        ))}
        {filtered.length === 0 && <div className="rounded-xl border border-dashed p-8 text-center text-sm text-muted-foreground">لا توجد عناصر</div>}
      </div>
    </div>
  );
}

function SiteTab() {
  const [maintenance, setMaintenance] = useState(false);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const snap = await getDocs(query(collection(db, "site")));
        const conf = snap.docs.find((d) => d.id === "config");
        if (conf) {
          const d = conf.data();
          setMaintenance(!!d.maintenance);
          setMessage(d.maintenanceMessage || "");
        }
      } catch {}
      finally { setLoading(false); }
    })();
  }, []);

  const save = async () => {
    setSaving(true);
    try {
      await setDoc(doc(db, "site", "config"), { maintenance, maintenanceMessage: message }, { merge: true });
      toast.success("تم الحفظ");
    } catch (e: any) { toast.error(e?.message); }
    finally { setSaving(false); }
  };

  if (loading) return <Center><Loader2 className="h-6 w-6 animate-spin text-primary" /></Center>;

  return (
    <div className="space-y-4 rounded-2xl border bg-card p-5">
      <h2 className="text-lg font-bold">إعدادات الموقع</h2>
      <div className="flex items-center justify-between rounded-xl border p-3">
        <div>
          <div className="font-bold">وضع الصيانة</div>
          <div className="text-xs text-muted-foreground">عند التفعيل، يُمنع الدخول للمستخدمين</div>
        </div>
        <Switch checked={maintenance} onCheckedChange={setMaintenance} />
      </div>
      <div>
        <label className="text-sm font-medium">رسالة الصيانة</label>
        <Input value={message} onChange={(e) => setMessage(e.target.value)} className="mt-1" placeholder="نعمل على تحديث الموقع، عُد لاحقاً" />
      </div>
      <Button onClick={save} disabled={saving} className="w-full">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "حفظ"}</Button>
    </div>
  );
}

function Center({ children }: { children: React.ReactNode }) {
  return <div className="flex justify-center py-10">{children}</div>;
}
