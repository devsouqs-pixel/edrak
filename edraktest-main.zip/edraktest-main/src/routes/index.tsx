import { createFileRoute } from "@tanstack/react-router";
import { FeedPage } from "@/components/feed/FeedPage";

export const Route = createFileRoute("/")({
  component: FeedPage,
  head: () => ({ meta: [{ title: "الرئيسية — إدراك" }] }),
});
