import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { collection, onSnapshot, query, where, orderBy } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Link, useNavigate } from "@tanstack/react-router";
import { Search, Plus, Users, Lock, Clock, BookOpen, GraduationCap } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";

export const Route = createFileRoute("/rooms/")({
  component: RoomsPage,
  head: () => ({ meta: [{ title: "الغرف الدراسية — إدراك" }] }),
});

interface Room {
  id: string; name: string; grade: string; subject: string;
  isPrivate: boolean; code?: string; memberCount: number; ownerId: string;
  status: "waiting" | "active" | "ended";
}

function RoomsPage() {
  const [rooms, setRooms] = useState<Room[]>([]);
  const [search, setSearch] = useState("");
  const [codeRoom, setCodeRoom] = useState<Room | null>(null);
  const [code, setCode] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const q = query(collection(db, "rooms"), where("status", "in", ["waiting", "active"]), orderBy("createdAt", "desc"));
    return onSnapshot(q, (snap) => setRooms(snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }))));
  }, []);

  const filtered = rooms.filter((r) => r.name.toLowerCase().includes(search.toLowerCase()));

  const enter = (r: Room) => {
    if (r.isPrivate) { setCodeRoom(r); setCode(""); }
    else navigate({ to: "/rooms/$roomId", params: { roomId: r.id } });
  };
  const submitCode = () => {
    if (!codeRoom) return;
    if (code === codeRoom.code) { navigate({ to: "/rooms/$roomId", params: { roomId: codeRoom.id } }); setCodeRoom(null); }
    else toast.error("الكود غير صحيح");
  };

  return (
    <div className="mx-auto max-w-6xl px-4 py-6">
      <div className="mb-6 flex items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black">الغرف الدراسية</h1>
          <p className="text-sm text-muted-foreground">انضم لجولة موجودة أو ابدأ جولتك الخاصة</p>
        </div>
        <Button asChild className="gap-2"><Link to="/rooms/new"><Plus className="h-4 w-4" />جولة جديدة</Link></Button>
      </div>

      <div className="relative mb-6">
        <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث باسم الغرفة..." className="h-12 pr-10 text-base" />
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed bg-card/50 py-16 text-center">
          <p className="text-muted-foreground">لا توجد غرف متاحة. كن أول من ينشئ جولة!</p>
        </div>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((r) => (
            <button key={r.id} onClick={() => enter(r)} className="group relative overflow-hidden rounded-2xl border bg-card p-5 text-right shadow-soft transition hover:-translate-y-1 hover:shadow-glow">
              <div className="absolute inset-x-0 top-0 h-1 gradient-primary" />
              <div className="mb-3 flex items-start justify-between">
                <h3 className="text-lg font-bold leading-tight">{r.name}</h3>
                {r.isPrivate && <Lock className="h-4 w-4 text-muted-foreground" />}
              </div>
              <div className="space-y-1.5 text-sm text-muted-foreground">
                <div className="flex items-center gap-2"><GraduationCap className="h-4 w-4" />{r.grade}</div>
                <div className="flex items-center gap-2"><BookOpen className="h-4 w-4" />{r.subject}</div>
              </div>
              <div className="mt-4 flex items-center justify-between border-t pt-3">
                <span className="flex items-center gap-1.5 text-xs"><Users className="h-3.5 w-3.5" />{r.memberCount || 0} عضو</span>
                <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${r.status === "active" ? "bg-green-500/10 text-green-600" : "bg-amber-500/10 text-amber-600"}`}>
                  {r.status === "active" ? "نشطة" : "بالانتظار"}
                </span>
              </div>
            </button>
          ))}
        </div>
      )}

      <Dialog open={!!codeRoom} onOpenChange={(o) => !o && setCodeRoom(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>غرفة خاصة — أدخل الكود</DialogTitle></DialogHeader>
          <Input value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, "").slice(0, 4))} placeholder="0000" maxLength={4} className="text-center text-2xl tracking-widest" />
          <Button onClick={submitCode} disabled={code.length !== 4}>دخول</Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
