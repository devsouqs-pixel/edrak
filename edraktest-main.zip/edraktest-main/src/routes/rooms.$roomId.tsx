import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  doc, onSnapshot, updateDoc, arrayUnion, arrayRemove, increment,
  collection, addDoc, query, orderBy, serverTimestamp, deleteDoc,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatTimer } from "@/lib/time";
import { awardPoints } from "@/lib/points";
import { POINTS } from "@/lib/constants";
import { toast } from "sonner";
import {
  Eye, EyeOff, Share2, LogOut, Send, Pin, Reply, Trash2, Settings as Cog,
  MessageSquareOff, MessageSquare, X, Crown, Loader2,
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";

export const Route = createFileRoute("/rooms/$roomId")({
  component: RoomPage,
  head: () => ({ meta: [{ title: "غرفة دراسية — إدراك" }] }),
});

interface Room {
  name: string; grade: string; subject: string; ownerId: string; ownerName: string;
  mode: "duration" | "target"; duration: number; endsAt: number;
  isPrivate: boolean; chatDisabled: boolean; status: "waiting" | "active" | "ended";
  memberCount: number; members: string[]; pinnedMessage?: string | null;
}
interface Msg { id: string; uid: string; name: string; photo: string; text: string; createdAt: any; replyTo?: { name: string; text: string } | null; pinned?: boolean; }

function RoomPage() {
  const { roomId } = Route.useParams();
  const { user, userData } = useAuth();
  const navigate = useNavigate();
  const [room, setRoom] = useState<Room | null>(null);
  const [now, setNow] = useState(Date.now());
  const [showChat, setShowChat] = useState(true);
  const [focus, setFocus] = useState(false);
  const [msg, setMsg] = useState("");
  const [messages, setMessages] = useState<Msg[]>([]);
  const [replyTo, setReplyTo] = useState<Msg | null>(null);
  const [lastSent, setLastSent] = useState(0);
  const [showSettings, setShowSettings] = useState(false);
  const [editName, setEditName] = useState("");
  const joinedRef = useRef(false);
  const completedRef = useRef(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  // Subscribe room
  useEffect(() => {
    const unsub = onSnapshot(doc(db, "rooms", roomId), (snap) => {
      if (!snap.exists()) { toast.error("الغرفة غير موجودة"); navigate({ to: "/rooms" }); return; }
      setRoom(snap.data() as Room);
    });
    return unsub;
  }, [roomId, navigate]);

  // Subscribe messages
  useEffect(() => {
    const q = query(collection(db, "rooms", roomId, "messages"), orderBy("createdAt", "asc"));
    return onSnapshot(q, (snap) => {
      setMessages(snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
      setTimeout(() => chatEndRef.current?.scrollIntoView({ behavior: "smooth" }), 50);
    });
  }, [roomId]);

  // Tick
  useEffect(() => { const i = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(i); }, []);

  // Join
  useEffect(() => {
    if (!user || !room || joinedRef.current) return;
    if (!room.members?.includes(user.uid)) {
      joinedRef.current = true;
      updateDoc(doc(db, "rooms", roomId), {
        members: arrayUnion(user.uid),
        memberCount: increment(1),
        status: "active",
      });
    } else { joinedRef.current = true; }
  }, [user, room, roomId]);

  // End handling
  const remaining = room ? Math.max(0, Math.floor((room.endsAt - now) / 1000)) : 0;
  const totalSec = room ? Math.max(1, room.duration * 60) : 1;
  const progress = room ? Math.min(100, ((totalSec - remaining) / totalSec) * 100) : 0;

  useEffect(() => {
    if (!room || !user || completedRef.current) return;
    if (remaining === 0 && room.status !== "ended") {
      completedRef.current = true;
      (async () => {
        await updateDoc(doc(db, "rooms", roomId), { status: "ended" }).catch(() => {});
        if (room.members?.includes(user.uid)) {
          await awardPoints(user.uid, POINTS.COMPLETE_ROUND, {
            completedRounds: increment(1),
            studyMinutes: increment(room.duration),
          });
          toast.success("انتهت الجلسة! +3 نقاط 🎉", { duration: 6000 });
        }
        setTimeout(async () => {
          await deleteDoc(doc(db, "rooms", roomId)).catch(() => {});
          navigate({ to: "/rooms" });
        }, 3 * 60 * 1000);
      })();
    }
  }, [remaining, room, user, roomId, navigate]);

  if (!room || !user || !userData) {
    return <div className="flex min-h-[60vh] items-center justify-center"><Loader2 className="h-8 w-8 animate-spin text-primary" /></div>;
  }

  const isOwner = room.ownerId === user.uid;

  const sendMsg = async () => {
    if (!msg.trim() || room.chatDisabled) return;
    const cooldown = POINTS.CHAT_COOLDOWN_MS;
    if (Date.now() - lastSent < cooldown) {
      toast.info(`انتظر ${Math.ceil((cooldown - (Date.now() - lastSent)) / 1000)}ث`);
      return;
    }
    await addDoc(collection(db, "rooms", roomId, "messages"), {
      uid: user.uid, name: userData.displayName, photo: userData.photoURL,
      text: msg.trim(), createdAt: serverTimestamp(),
      replyTo: replyTo ? { name: replyTo.name, text: replyTo.text.slice(0, 80) } : null,
    });
    await awardPoints(user.uid, POINTS.CHAT_MESSAGE);
    setMsg(""); setReplyTo(null); setLastSent(Date.now());
  };

  const leave = async () => {
    if (room.members?.includes(user.uid)) {
      await updateDoc(doc(db, "rooms", roomId), {
        members: arrayRemove(user.uid),
        memberCount: increment(-1),
      }).catch(() => {});
    }
    navigate({ to: "/rooms" });
  };

  const pinMsg = async (m: Msg) => {
    await updateDoc(doc(db, "rooms", roomId), { pinnedMessage: `${m.name}: ${m.text}` });
    toast.success("تم التثبيت");
  };
  const unpin = async () => updateDoc(doc(db, "rooms", roomId), { pinnedMessage: null });

  const toggleChat = async () => updateDoc(doc(db, "rooms", roomId), { chatDisabled: !room.chatDisabled });
  const dissolve = async () => {
    if (!confirm("تفكيك الغرفة نهائياً؟")) return;
    await deleteDoc(doc(db, "rooms", roomId));
    navigate({ to: "/rooms" });
  };
  const saveSettings = async () => {
    if (!editName.trim()) return;
    await updateDoc(doc(db, "rooms", roomId), { name: editName.trim() });
    setShowSettings(false);
    toast.success("تم الحفظ");
  };
  const share = async () => {
    const url = window.location.href;
    try { await navigator.clipboard.writeText(url); toast.success("تم نسخ الرابط"); } catch {}
  };

  return (
    <div className={`mx-auto px-4 py-4 ${focus ? "max-w-3xl" : "max-w-7xl"}`}>
      {/* Header */}
      <div className="mb-4 rounded-2xl border bg-card p-4 shadow-soft">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-black">{room.name}</h1>
              {isOwner && <Crown className="h-4 w-4 text-amber-500" />}
            </div>
            <p className="text-xs text-muted-foreground">{room.subject} • {room.grade}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant={focus ? "default" : "outline"} onClick={() => setFocus(!focus)}>وضع التركيز</Button>
            <Button size="sm" variant="outline" onClick={() => setShowChat(!showChat)}>
              {showChat ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </Button>
            <Button size="sm" variant="outline" onClick={share}><Share2 className="h-4 w-4" /></Button>
            {isOwner && <Button size="sm" variant="outline" onClick={() => { setEditName(room.name); setShowSettings(true); }}><Cog className="h-4 w-4" /></Button>}
            <Button size="sm" variant="destructive" onClick={leave}><LogOut className="h-4 w-4" /></Button>
          </div>
        </div>
      </div>

      <div className={`grid gap-4 ${focus || !showChat ? "grid-cols-1" : "lg:grid-cols-3"}`}>
        {/* Timer + members */}
        <div className={focus || !showChat ? "" : "lg:col-span-2"}>
          <div className="rounded-3xl border bg-gradient-to-br from-card to-muted/30 p-8 shadow-soft text-center">
            <div className="text-xs uppercase tracking-widest text-muted-foreground">{room.status === "ended" ? "انتهت الجلسة" : "الوقت المتبقي"}</div>
            <div className="my-4 font-mono text-7xl font-black text-gradient">{formatTimer(remaining)}</div>
            <div className="mx-auto h-2 w-full max-w-md overflow-hidden rounded-full bg-muted">
              <div className="h-full gradient-primary transition-all" style={{ width: `${progress}%` }} />
            </div>
            <div className="mt-6 grid grid-cols-3 gap-2 text-sm">
              <div><div className="text-2xl font-black">{room.memberCount || 0}</div><div className="text-xs text-muted-foreground">أعضاء</div></div>
              <div><div className="text-2xl font-black">{room.duration}د</div><div className="text-xs text-muted-foreground">مدة الجلسة</div></div>
              <div><div className="text-2xl font-black">{Math.round(progress)}%</div><div className="text-xs text-muted-foreground">إنجاز</div></div>
            </div>
          </div>
        </div>

        {/* Chat */}
        {showChat && !focus && (
          <div className="flex h-[600px] flex-col rounded-2xl border bg-card shadow-soft">
            <div className="flex items-center justify-between border-b p-3">
              <h3 className="font-bold">الشات المباشر</h3>
              {isOwner && (
                <Button variant="ghost" size="sm" onClick={toggleChat} className="gap-2 text-xs">
                  {room.chatDisabled ? <MessageSquare className="h-3 w-3" /> : <MessageSquareOff className="h-3 w-3" />}
                  {room.chatDisabled ? "تفعيل" : "تعطيل"}
                </Button>
              )}
            </div>

            {room.pinnedMessage && (
              <div className="flex items-center justify-between gap-2 border-b bg-amber-500/10 px-3 py-2 text-xs">
                <div className="flex items-center gap-1.5"><Pin className="h-3 w-3" /><span className="truncate">{room.pinnedMessage}</span></div>
                {isOwner && <button onClick={unpin}><X className="h-3 w-3" /></button>}
              </div>
            )}

            <div className="flex-1 space-y-2 overflow-y-auto p-3">
              {messages.map((m) => (
                <div key={m.id} className="group flex items-start gap-2">
                  <Avatar className="h-7 w-7"><AvatarImage src={m.photo} /><AvatarFallback>{m.name?.[0]}</AvatarFallback></Avatar>
                  <div className="flex-1">
                    {m.replyTo && <div className="mb-1 truncate rounded border-r-2 border-primary bg-muted/50 px-2 py-1 text-xs text-muted-foreground">{m.replyTo.name}: {m.replyTo.text}</div>}
                    <div className="rounded-2xl bg-muted px-3 py-1.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-semibold">{m.name}</span>
                        <div className="flex gap-1 opacity-0 transition group-hover:opacity-100">
                          <button onClick={() => setReplyTo(m)} title="رد"><Reply className="h-3 w-3 text-muted-foreground" /></button>
                          {isOwner && <button onClick={() => pinMsg(m)} title="تثبيت"><Pin className="h-3 w-3 text-muted-foreground" /></button>}
                        </div>
                      </div>
                      <p className="break-words text-sm">{m.text}</p>
                    </div>
                  </div>
                </div>
              ))}
              <div ref={chatEndRef} />
            </div>

            <div className="border-t p-3">
              {replyTo && (
                <div className="mb-2 flex items-center justify-between rounded bg-muted px-2 py-1 text-xs">
                  <span>رد على {replyTo.name}</span>
                  <button onClick={() => setReplyTo(null)}><X className="h-3 w-3" /></button>
                </div>
              )}
              {room.chatDisabled ? (
                <div className="text-center text-xs text-muted-foreground">الشات معطّل</div>
              ) : (
                <div className="flex gap-2">
                  <Input value={msg} onChange={(e) => setMsg(e.target.value.slice(0, 300))} onKeyDown={(e) => e.key === "Enter" && sendMsg()} placeholder="اكتب رسالة..." className="text-sm" />
                  <Button size="icon" onClick={sendMsg} disabled={!msg.trim()}><Send className="h-4 w-4" /></Button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Owner settings dialog */}
      <Dialog open={showSettings} onOpenChange={setShowSettings}>
        <DialogContent>
          <DialogHeader><DialogTitle>إعدادات الغرفة</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-sm font-semibold">اسم الغرفة</label>
              <Input value={editName} onChange={(e) => setEditName(e.target.value)} className="mt-1" />
            </div>
            <Button variant="destructive" onClick={dissolve} className="w-full gap-2">
              <Trash2 className="h-4 w-4" />تفكيك الغرفة
            </Button>
          </div>
          <DialogFooter><Button onClick={saveSettings}>حفظ</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
