import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { collection, getDocs, limit, orderBy, query, where } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/contexts/AuthContext";
import { Loader2, MessageSquare, Trophy, Clock, Upload, FileText } from "lucide-react";
import { getRank } from "@/lib/constants";

export const Route = createFileRoute("/activity")({
  component: ActivityPage,
  head: () => ({ meta: [{ title: "نشاطي — إدراك" }] }),
});

function ActivityPage() {
  const { user, userData } = useAuth();
  const [posts, setPosts] = useState<any[]>([]);
  const [files, setFiles] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    (async () => {
      try {
        const [pSnap, fSnap] = await Promise.all([
          getDocs(query(collection(db, "posts"), where("authorId", "==", user.uid), limit(20))).catch(() => null),
          getDocs(query(collection(db, "files"), where("uploaderId", "==", user.uid), limit(20))).catch(() => null),
        ]);
        if (pSnap) setPosts(pSnap.docs.map((d) => ({ id: d.id, ...d.data() })));
        if (fSnap) setFiles(fSnap.docs.map((d) => ({ id: d.id, ...d.data() })));
      } finally { setLoading(false); }
    })();
  }, [user]);

  if (!userData) return null;
  const rank = getRank(userData.points || 0);

  return (
    <div className="mx-auto max-w-3xl space-y-6 px-4 py-6">
      <h1 className="text-3xl font-black">نشاطي</h1>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat icon={Trophy} label="النقاط" value={userData.points || 0} color={rank.color} />
        <Stat icon={Clock} label="الجولات" value={userData.completedRounds || 0} color="#3b82f6" />
        <Stat icon={MessageSquare} label="المنشورات" value={posts.length} color="#10b981" />
        <Stat icon={Upload} label="الملفات" value={files.length} color="#f59e0b" />
      </div>

      <div className="rounded-2xl border bg-card p-5 shadow-soft">
        <h2 className="mb-3 text-lg font-bold">الرتبة الحالية</h2>
        <div className="flex items-center gap-3">
          <div className="flex h-14 w-14 items-center justify-center rounded-xl text-white text-2xl font-black" style={{ background: rank.color }}>
            {rank.name[0]}
          </div>
          <div>
            <div className="text-xl font-black" style={{ color: rank.color }}>{rank.name}</div>
            <div className="text-sm text-muted-foreground">{userData.points} نقطة</div>
          </div>
        </div>
      </div>

      <Section title="منشوراتي" icon={MessageSquare}>
        {loading ? <Center /> : posts.length === 0 ? <Empty text="لم تنشر شيئاً بعد" /> :
          posts.map((p) => (
            <div key={p.id} className="rounded-xl border bg-background p-3 text-sm">
              <div className="line-clamp-2">{p.content}</div>
              <div className="mt-1 text-xs text-muted-foreground">❤️ {p.likes || 0} • 💬 {p.commentsCount || 0}</div>
            </div>
          ))
        }
      </Section>

      <Section title="ملفاتي" icon={FileText}>
        {loading ? <Center /> : files.length === 0 ? <Empty text="لم ترفع ملفات بعد" /> :
          files.map((f) => (
            <div key={f.id} className="rounded-xl border bg-background p-3 text-sm">
              <div className="font-bold">{f.title}</div>
              <div className="text-xs text-muted-foreground">{f.grade} {f.subject ? `• ${f.subject}` : ""}</div>
            </div>
          ))
        }
      </Section>
    </div>
  );
}

function Stat({ icon: Icon, label, value, color }: any) {
  return (
    <div className="rounded-xl border bg-card p-3 text-center">
      <Icon className="mx-auto h-5 w-5" style={{ color }} />
      <div className="mt-1 text-2xl font-black tabular-nums">{value}</div>
      <div className="text-xs text-muted-foreground">{label}</div>
    </div>
  );
}
function Section({ title, icon: Icon, children }: any) {
  return (
    <div className="rounded-2xl border bg-card p-5 shadow-soft">
      <h2 className="mb-3 flex items-center gap-2 text-lg font-bold"><Icon className="h-4 w-4 text-primary" />{title}</h2>
      <div className="space-y-2">{children}</div>
    </div>
  );
}
function Center() { return <div className="flex justify-center py-4"><Loader2 className="h-5 w-5 animate-spin text-primary" /></div>; }
function Empty({ text }: { text: string }) { return <div className="rounded-xl border border-dashed p-6 text-center text-sm text-muted-foreground">{text}</div>; }
