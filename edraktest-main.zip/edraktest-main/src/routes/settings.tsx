import { createFileRoute } from "@tanstack/react-router";
import { useTheme } from "@/contexts/ThemeContext";
import { useAuth } from "@/contexts/AuthContext";
import { COLOR_PRESETS, GRADES } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Sun, Moon, Check, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/settings")({
  component: SettingsPage,
  head: () => ({ meta: [{ title: "الإعدادات — إدراك" }] }),
});

function SettingsPage() {
  const { mode, color, setMode, setColor } = useTheme();
  const { userData, updateUserData } = useAuth();
  const [name, setName] = useState(userData?.displayName || "");
  const [bio, setBio] = useState(userData?.bio || "");
  const [grade, setGrade] = useState(userData?.grade || "");
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    try { await updateUserData({ displayName: name, bio, grade }); toast.success("تم الحفظ"); }
    catch (e: any) { toast.error("فشل الحفظ", { description: e?.message }); }
    finally { setSaving(false); }
  };

  if (!userData) return null;

  return (
    <div className="mx-auto max-w-2xl space-y-6 px-4 py-6">
      <h1 className="text-3xl font-black">الإعدادات</h1>

      <Section title="المظهر">
        <div className="flex gap-2">
          <button onClick={() => setMode("light")} className={`flex-1 rounded-xl border p-3 text-center ${mode === "light" ? "border-primary bg-accent" : ""}`}>
            <Sun className="mx-auto h-5 w-5" /><div className="mt-1 text-sm">نهاري</div>
          </button>
          <button onClick={() => setMode("dark")} className={`flex-1 rounded-xl border p-3 text-center ${mode === "dark" ? "border-primary bg-accent" : ""}`}>
            <Moon className="mx-auto h-5 w-5" /><div className="mt-1 text-sm">ليلي</div>
          </button>
        </div>
        <div className="mt-4">
          <Label>اللون المفضل</Label>
          <div className="mt-2 flex flex-wrap gap-2">
            {COLOR_PRESETS.map((c) => (
              <button key={c.value} onClick={() => setColor(c.value)}
                className={`flex items-center gap-2 rounded-full border px-3 py-2 text-xs ${color === c.value ? "border-primary" : ""}`}>
                <span className="h-4 w-4 rounded-full" style={{ backgroundColor: `hsl(${c.primary})` }} />
                {c.name}
                {color === c.value && <Check className="h-3 w-3" />}
              </button>
            ))}
          </div>
        </div>
      </Section>

      <Section title="معلومات الحساب">
        <div className="space-y-3">
          <div><Label>اسم الظهور</Label><Input value={name} onChange={(e) => setName(e.target.value)} className="mt-1" /></div>
          <div><Label>نبذة</Label><Textarea value={bio} onChange={(e) => setBio(e.target.value.slice(0, 200))} className="mt-1" /></div>
          <div>
            <Label>الصف الدراسي</Label>
            <div className="mt-2 flex flex-wrap gap-2">
              {GRADES.map((g) => (
                <button key={g} onClick={() => setGrade(g)} className={`rounded-full border px-3 py-1 text-xs ${grade === g ? "border-primary bg-primary text-primary-foreground" : ""}`}>{g}</button>
              ))}
            </div>
          </div>
          <Button onClick={save} disabled={saving} className="w-full">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "حفظ التغييرات"}</Button>
        </div>
      </Section>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border bg-card p-5 shadow-soft">
      <h2 className="mb-4 text-lg font-bold">{title}</h2>
      {children}
    </div>
  );
}
