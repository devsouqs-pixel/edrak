import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { collection, addDoc, serverTimestamp, query, orderBy, onSnapshot, doc, deleteDoc } from "firebase/firestore";
import { ref as sref, deleteObject } from "firebase/storage";
import { db, storage } from "@/lib/firebase";
import { uploadFile } from "@/lib/upload";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FILE_GRADES, SUBJECTS_BY_GRADE, POINTS } from "@/lib/constants";
import { awardPoints } from "@/lib/points";
import { formatRelative } from "@/lib/time";
import { Upload, Search, FileText, Download, Trash2, Loader2, Plus } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/files")({
  component: FilesPage,
  head: () => ({ meta: [{ title: "الملفات — إدراك" }] }),
});

const SUBJECT_KEY = (g: string) =>
  g === "ثاني ثانوي" ? "ثاني ثانوي" : g === "أول ثانوي" ? "أول ثانوي" : "عاشر";

interface FileItem {
  id: string;
  uid: string;
  authorName: string;
  authorPhoto: string;
  title: string;
  description: string;
  grade: string;
  subject: string;
  url: string;
  storagePath: string;
  size: number;
  fileName: string;
  createdAt: any;
}

function FilesPage() {
  const { user, userData } = useAuth();
  const [items, setItems] = useState<FileItem[]>([]);
  const [search, setSearch] = useState("");
  const [gradeFilter, setGradeFilter] = useState<string>("all");
  const [subjectFilter, setSubjectFilter] = useState<string>("all");
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const q = query(collection(db, "files"), orderBy("createdAt", "desc"));
    return onSnapshot(q, (s) => setItems(s.docs.map((d) => ({ id: d.id, ...(d.data() as any) }))));
  }, []);

  const subjects = gradeFilter === "all" ? [] : SUBJECTS_BY_GRADE[SUBJECT_KEY(gradeFilter)] || [];

  const filtered = items.filter((it) => {
    if (gradeFilter !== "all" && it.grade !== gradeFilter) return false;
    if (subjectFilter !== "all" && it.subject !== subjectFilter) return false;
    if (search.trim()) {
      const s = search.toLowerCase();
      if (!it.title.toLowerCase().includes(s) && !it.description.toLowerCase().includes(s)) return false;
    }
    return true;
  });

  return (
    <div className="mx-auto max-w-5xl px-4 py-6">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black">مكتبة الملفات</h1>
          <p className="text-sm text-muted-foreground">شارك ملفاتك واكسب +{POINTS.UPLOAD_FILE} نقاط لكل ملف</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button className="gap-2"><Plus className="h-4 w-4" /> رفع ملف</Button></DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader><DialogTitle>رفع ملف جديد</DialogTitle></DialogHeader>
            <UploadForm onDone={() => setOpen(false)} />
          </DialogContent>
        </Dialog>
      </div>

      <div className="mb-4 grid gap-3 rounded-2xl border bg-card p-4 sm:grid-cols-3">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث..." className="pr-9" />
        </div>
        <Select value={gradeFilter} onValueChange={(v) => { setGradeFilter(v); setSubjectFilter("all"); }}>
          <SelectTrigger><SelectValue placeholder="كل الصفوف" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل الصفوف</SelectItem>
            {FILE_GRADES.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}
          </SelectContent>
        </Select>
        <Select value={subjectFilter} onValueChange={setSubjectFilter} disabled={gradeFilter === "all"}>
          <SelectTrigger><SelectValue placeholder="كل المواد" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="all">كل المواد</SelectItem>
            {subjects.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <div className="rounded-2xl border border-dashed bg-card/50 py-16 text-center">
          <FileText className="mx-auto h-12 w-12 text-muted-foreground" />
          <p className="mt-3 text-sm text-muted-foreground">لا توجد ملفات</p>
        </div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((it) => <FileCard key={it.id} item={it} />)}
        </div>
      )}
    </div>
  );
}

function FileCard({ item }: { item: FileItem }) {
  const { user } = useAuth();
  const isOwner = user?.uid === item.uid;
  const remove = async () => {
    if (!confirm("حذف الملف؟")) return;
    try {
      await deleteDoc(doc(db, "files", item.id));
      if (item.storagePath) await deleteObject(sref(storage, item.storagePath)).catch(() => {});
      toast.success("تم الحذف");
    } catch (e: any) {
      toast.error("فشل الحذف", { description: e?.message });
    }
  };
  return (
    <div className="flex flex-col rounded-2xl border bg-card p-4 shadow-soft transition hover:shadow-md">
      <div className="mb-3 flex items-center gap-2">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <FileText className="h-5 w-5" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="truncate text-sm font-bold">{item.title}</h3>
          <div className="text-xs text-muted-foreground">{item.grade} • {item.subject}</div>
        </div>
      </div>
      {item.description && <p className="mb-3 line-clamp-2 text-xs text-muted-foreground">{item.description}</p>}
      <div className="mt-auto flex items-center justify-between border-t pt-3">
        <Link to="/u/$username" params={{ username: (item as any).authorUsername || "" }} className="flex items-center gap-2">
          <Avatar className="h-6 w-6"><AvatarImage src={item.authorPhoto} /><AvatarFallback>{item.authorName?.[0]}</AvatarFallback></Avatar>
          <span className="text-xs font-medium">{item.authorName}</span>
        </Link>
        <span className="text-[10px] text-muted-foreground">{formatRelative(item.createdAt)}</span>
      </div>
      <div className="mt-2 flex gap-2">
        <Button asChild size="sm" variant="default" className="flex-1 gap-2">
          <a href={item.url} target="_blank" rel="noopener noreferrer" download={item.fileName}>
            <Download className="h-4 w-4" /> تحميل
          </a>
        </Button>
        {isOwner && (
          <Button size="icon" variant="ghost" onClick={remove} className="text-destructive">
            <Trash2 className="h-4 w-4" />
          </Button>
        )}
      </div>
    </div>
  );
}

function UploadForm({ onDone }: { onDone: () => void }) {
  const { user, userData } = useAuth();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [grade, setGrade] = useState<string>("");
  const [subject, setSubject] = useState<string>("");
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState(0);
  const fileRef = useRef<HTMLInputElement>(null);

  const subjects = grade ? SUBJECTS_BY_GRADE[SUBJECT_KEY(grade)] || [] : [];

  const submit = async () => {
    if (!user || !userData) return;
    if (!title.trim() || !grade || !subject || !file) {
      toast.error("املأ جميع الحقول واختر ملف");
      return;
    }
    if (file.size > 25 * 1024 * 1024) { toast.error("الحد الأقصى 25MB"); return; }
    setBusy(true);
    setProgress(0);
    try {
      const safeName = file.name.replace(/[^\w.\-]/g, "_");
      const path = `files/${user.uid}/${Date.now()}_${safeName}`;
      const { url } = await uploadFile(path, file, {
        contentType: file.type || "application/octet-stream",
        onProgress: setProgress,
      });
      await addDoc(collection(db, "files"), {
        uid: user.uid,
        authorName: userData.displayName,
        authorUsername: userData.username,
        authorPhoto: userData.photoURL,
        title: title.trim(),
        description: description.trim(),
        grade, subject,
        url, storagePath: path,
        size: file.size,
        fileName: file.name,
        createdAt: serverTimestamp(),
      });
      await awardPoints(user.uid, POINTS.UPLOAD_FILE);
      toast.success(`تم النشر +${POINTS.UPLOAD_FILE} نقاط`);
      onDone();
    } catch (e: any) {
      toast.error("فشل الرفع", { description: e?.message });
    } finally { setBusy(false); setProgress(0); }
  };

  return (
    <div className="space-y-3">
      <div>
        <Label>العنوان</Label>
        <Input value={title} onChange={(e) => setTitle(e.target.value)} maxLength={80} />
      </div>
      <div>
        <Label>وصف مختصر</Label>
        <Input value={description} onChange={(e) => setDescription(e.target.value)} maxLength={140} />
      </div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div>
          <Label>الصف</Label>
          <Select value={grade} onValueChange={(v) => { setGrade(v); setSubject(""); }}>
            <SelectTrigger><SelectValue placeholder="اختر" /></SelectTrigger>
            <SelectContent>{FILE_GRADES.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
          </Select>
        </div>
        <div>
          <Label>المادة</Label>
          <Select value={subject} onValueChange={setSubject} disabled={!grade}>
            <SelectTrigger><SelectValue placeholder="اختر" /></SelectTrigger>
            <SelectContent>{subjects.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
          </Select>
        </div>
      </div>
      <div>
        <Label>الملف (حد أقصى 25MB)</Label>
        <input ref={fileRef} type="file" hidden onChange={(e) => setFile(e.target.files?.[0] || null)} />
        <Button type="button" variant="outline" className="w-full gap-2" onClick={() => fileRef.current?.click()}>
          <Upload className="h-4 w-4" /> {file ? file.name : "اختر ملف"}
        </Button>
      </div>
      {busy && progress > 0 && (
        <div className="space-y-1">
          <Progress value={progress} className="h-2" />
          <div className="text-xs text-muted-foreground text-center">{progress}%</div>
        </div>
      )}
      <Button onClick={submit} disabled={busy} className="w-full gap-2 gradient-gold text-background font-bold">
        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />} نشر
      </Button>
    </div>
  );
}
