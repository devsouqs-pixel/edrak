import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/contexts/AuthContext";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, ChevronRight, ChevronLeft, RotateCcw, Moon, BookOpen, Sparkles } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/islamic")({
  component: IslamicPage,
  head: () => ({ meta: [{ title: "القسم الديني — إدراك" }] }),
});

function IslamicPage() {
  return (
    <div className="mx-auto max-w-4xl space-y-6 px-4 py-6">
      <div className="text-center">
        <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl glass-gold mb-3">
          <Moon className="h-7 w-7 text-gold" />
        </div>
        <h1 className="text-3xl font-black text-gradient">القسم الديني</h1>
        <p className="mt-1 text-sm text-muted-foreground">مواقيت الصلاة • المصحف الشريف • المسبحة الإلكترونية</p>
      </div>

      <Tabs defaultValue="prayer" className="w-full">
        <TabsList className="grid w-full grid-cols-3 glass h-12 p-1">
          <TabsTrigger value="prayer" className="data-[state=active]:gradient-gold data-[state=active]:text-background data-[state=active]:font-black">مواقيت الصلاة</TabsTrigger>
          <TabsTrigger value="quran" className="data-[state=active]:gradient-gold data-[state=active]:text-background data-[state=active]:font-black">المصحف</TabsTrigger>
          <TabsTrigger value="tasbih" className="data-[state=active]:gradient-gold data-[state=active]:text-background data-[state=active]:font-black">المسبحة</TabsTrigger>
        </TabsList>
        <TabsContent value="prayer" className="mt-6"><PrayerTimes /></TabsContent>
        <TabsContent value="quran" className="mt-6"><Quran /></TabsContent>
        <TabsContent value="tasbih" className="mt-6"><Tasbih /></TabsContent>
      </Tabs>
    </div>
  );
}

const PRAYER_NAMES: Record<string, string> = {
  Fajr: "الفجر", Sunrise: "الشروق", Dhuhr: "الظهر",
  Asr: "العصر", Maghrib: "المغرب", Isha: "العشاء",
};

function PrayerTimes() {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [now, setNow] = useState(new Date());

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    (async () => {
      try {
        const r = await fetch("https://api.aladhan.com/v1/timingsByCity?city=Amman&country=Jordan&method=4");
        const j = await r.json();
        setData(j.data);
      } catch (e) {
        toast.error("تعذر جلب مواقيت الصلاة");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  if (loading) return <div className="flex justify-center py-10"><Loader2 className="h-6 w-6 animate-spin text-gold" /></div>;
  if (!data) return <div className="text-center text-muted-foreground">لا توجد بيانات</div>;

  const timings = data.timings as Record<string, string>;
  const order = ["Fajr", "Sunrise", "Dhuhr", "Asr", "Maghrib", "Isha"];

  const today = new Date();
  let nextName = "";
  let nextTs = 0;
  for (const k of order) {
    if (k === "Sunrise") continue;
    const [h, m] = timings[k].split(":").map(Number);
    const d = new Date(today); d.setHours(h, m, 0, 0);
    if (d.getTime() > now.getTime()) { nextName = k; nextTs = d.getTime(); break; }
  }
  if (!nextName) {
    const [h, m] = timings.Fajr.split(":").map(Number);
    const d = new Date(today); d.setDate(d.getDate() + 1); d.setHours(h, m, 0, 0);
    nextName = "Fajr"; nextTs = d.getTime();
  }
  const diff = Math.max(0, nextTs - now.getTime());
  const hh = String(Math.floor(diff / 3600000)).padStart(2, "0");
  const mm = String(Math.floor((diff % 3600000) / 60000)).padStart(2, "0");
  const ss = String(Math.floor((diff % 60000) / 1000)).padStart(2, "0");

  return (
    <div className="space-y-4">
      <div className="glass rounded-2xl p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-xs text-muted-foreground">التاريخ الميلادي</div>
            <div className="font-bold">{data.date.gregorian.date}</div>
          </div>
          <div>
            <div className="text-xs text-muted-foreground">التاريخ الهجري</div>
            <div className="font-bold text-gold">
              {data.date.hijri.day} {data.date.hijri.month.ar} {data.date.hijri.year}
            </div>
          </div>
          <div className="text-left">
            <div className="text-xs text-muted-foreground">المدينة</div>
            <div className="font-bold">عمّان، الأردن</div>
          </div>
        </div>
      </div>

      <div className="glass-gold rounded-3xl p-8 text-center relative overflow-hidden">
        <div className="absolute inset-0 -z-0 opacity-30 [background-image:radial-gradient(hsl(var(--gold))_1px,transparent_1px)] [background-size:20px_20px]" />
        <div className="relative">
          <div className="text-xs uppercase tracking-[0.3em] text-gold/80 font-bold">الصلاة القادمة</div>
          <div className="mt-2 text-4xl font-black text-gradient">{PRAYER_NAMES[nextName]}</div>
          <div className="mt-4 font-mono text-5xl font-black tabular-nums text-foreground">
            {hh}<span className="text-gold/60">:</span>{mm}<span className="text-gold/60">:</span>{ss}
          </div>
          <div className="mt-1 text-xs text-muted-foreground">الوقت المتبقي</div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {order.map((k) => {
          const active = k === nextName;
          return (
            <div key={k} className={`rounded-2xl p-4 text-center transition-all ${active ? "glass-gold animate-glow" : "glass"}`}>
              <div className={`text-sm ${active ? "text-gold" : "text-muted-foreground"}`}>{PRAYER_NAMES[k]}</div>
              <div className="mt-1 text-xl font-black tabular-nums">{timings[k]}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============ QURAN via alquran.cloud ============

interface Surah { number: number; name: string; englishName: string; numberOfAyahs: number; revelationType: string; }
interface Ayah { number: number; text: string; numberInSurah: number; juz: number; page: number; }

function Quran() {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [selectedSurah, setSelectedSurah] = useState<number>(1);
  const [ayahs, setAyahs] = useState<Ayah[]>([]);
  const [loading, setLoading] = useState(true);
  const [bismillah, setBismillah] = useState(true);

  // load surah list
  useEffect(() => {
    (async () => {
      try {
        const r = await fetch("https://api.alquran.cloud/v1/surah");
        const j = await r.json();
        setSurahs(j.data || []);
      } catch {
        toast.error("تعذر جلب قائمة السور");
      }
    })();
  }, []);

  // load surah text (Uthmani script with tashkeel)
  useEffect(() => {
    setLoading(true);
    (async () => {
      try {
        const r = await fetch(`https://api.alquran.cloud/v1/surah/${selectedSurah}/quran-uthmani`);
        const j = await r.json();
        setAyahs(j.data?.ayahs || []);
        setBismillah(selectedSurah !== 1 && selectedSurah !== 9);
        // restore last position
        try { localStorage.setItem("edrak.quran.surah", String(selectedSurah)); } catch {}
      } catch {
        toast.error("تعذر تحميل السورة");
      } finally {
        setLoading(false);
      }
    })();
  }, [selectedSurah]);

  // restore on mount
  useEffect(() => {
    try {
      const last = parseInt(localStorage.getItem("edrak.quran.surah") || "1");
      if (last >= 1 && last <= 114) setSelectedSurah(last);
    } catch {}
  }, []);

  const current = surahs.find((s) => s.number === selectedSurah);

  return (
    <div className="space-y-4">
      {/* Selector */}
      <div className="glass rounded-2xl p-3 flex flex-wrap items-center gap-2">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => setSelectedSurah((n) => Math.min(114, n + 1))}
          disabled={selectedSurah >= 114}
          className="text-gold"
        >
          <ChevronRight className="h-4 w-4" />
        </Button>

        <Select value={String(selectedSurah)} onValueChange={(v) => setSelectedSurah(parseInt(v))}>
          <SelectTrigger className="flex-1 min-w-[200px] border-gold/30 bg-card/50">
            <SelectValue placeholder="اختر سورة" />
          </SelectTrigger>
          <SelectContent className="max-h-80">
            {surahs.map((s) => (
              <SelectItem key={s.number} value={String(s.number)}>
                <span className="font-mono text-gold ml-2">{s.number}.</span>
                {s.name} <span className="text-xs text-muted-foreground mr-2">({s.numberOfAyahs} آية)</span>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Button
          variant="ghost"
          size="icon"
          onClick={() => setSelectedSurah((n) => Math.max(1, n - 1))}
          disabled={selectedSurah <= 1}
          className="text-gold"
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
      </div>

      {/* Quran display */}
      <div className="glass-strong rounded-3xl overflow-hidden relative">
        {/* Header band */}
        <div className="gradient-gold px-6 py-4 text-center text-background relative">
          <div className="absolute inset-0 opacity-20 [background-image:radial-gradient(circle,white_1px,transparent_1px)] [background-size:16px_16px]" />
          <div className="relative">
            <div className="text-[10px] uppercase tracking-[0.3em] font-bold opacity-90">سورة</div>
            <div className="text-2xl font-black mt-0.5">{current?.name}</div>
            <div className="text-xs mt-1 opacity-80">
              {current?.englishName} • {current?.numberOfAyahs} آية •{" "}
              {current?.revelationType === "Meccan" ? "مكية" : "مدنية"}
            </div>
          </div>
        </div>

        {loading ? (
          <div className="flex h-96 items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-gold" />
          </div>
        ) : (
          <div className="p-6 md:p-10" dir="rtl">
            {bismillah && (
              <div className="text-center mb-6 text-2xl md:text-3xl text-gold font-bold mushaf-text">
                بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ
              </div>
            )}
            <p className="mushaf-text">
              {ayahs.map((a) => {
                // strip leading bismillah from first ayah of surahs (api includes it)
                let text = a.text;
                if (a.numberInSurah === 1 && selectedSurah !== 1 && selectedSurah !== 9) {
                  text = text.replace(/^بِسْمِ\s+ٱللَّهِ\s+ٱلرَّحْمَٰنِ\s+ٱلرَّحِيمِ\s*/, "");
                }
                return (
                  <span key={a.number}>
                    {text}
                    <span className="inline-flex items-center justify-center mx-1 h-7 w-7 rounded-full border border-gold/40 text-gold text-xs font-bold tabular-nums align-middle">
                      {a.numberInSurah}
                    </span>{" "}
                  </span>
                );
              })}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

// ============ TASBIH ============
const DHIKRS = ["سبحان الله", "الحمد لله", "الله أكبر", "لا إله إلا الله", "أستغفر الله"];

function Tasbih() {
  const { user } = useAuth();
  const [count, setCount] = useState(0);
  const [total, setTotal] = useState(0);
  const [dhikrIdx, setDhikrIdx] = useState(0);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const snap = await getDoc(doc(db, "tasbih", user.uid));
      if (snap.exists()) {
        const d = snap.data();
        setCount(d.count || 0);
        setTotal(d.total || 0);
        setDhikrIdx(d.dhikrIdx || 0);
      }
      setLoaded(true);
    })();
  }, [user]);

  useEffect(() => {
    if (!user || !loaded) return;
    setDoc(doc(db, "tasbih", user.uid), { count, total, dhikrIdx }, { merge: true }).catch(() => {});
  }, [count, total, dhikrIdx, user, loaded]);

  const tap = () => {
    setCount((c) => c + 1);
    setTotal((t) => t + 1);
    if (navigator.vibrate) navigator.vibrate(20);
  };

  return (
    <div className="space-y-4">
      <div className="glass rounded-2xl p-5 text-center">
        <div className="text-xs text-muted-foreground uppercase tracking-widest">الذكر الحالي</div>
        <div className="mt-2 text-3xl font-black text-gradient">{DHIKRS[dhikrIdx]}</div>
        <div className="mt-3 flex flex-wrap justify-center gap-2">
          {DHIKRS.map((d, i) => (
            <button
              key={i}
              onClick={() => { setDhikrIdx(i); setCount(0); }}
              className={`rounded-full border px-3 py-1.5 text-xs font-bold transition ${
                dhikrIdx === i
                  ? "gradient-gold border-transparent text-background shadow-gold"
                  : "border-gold/30 text-muted-foreground hover:text-gold"
              }`}
            >
              {d}
            </button>
          ))}
        </div>
      </div>

      <button
        onClick={tap}
        className="group relative flex h-72 w-full items-center justify-center rounded-3xl gradient-gold text-background shadow-gold active:scale-95 transition-transform overflow-hidden"
      >
        <div className="absolute inset-0 opacity-30 [background-image:radial-gradient(circle,white_1px,transparent_1px)] [background-size:24px_24px]" />
        <div className="relative text-center">
          <Sparkles className="h-6 w-6 mx-auto mb-2 opacity-70" />
          <div className="text-7xl font-black tabular-nums">{count}</div>
          <div className="mt-2 text-sm font-bold opacity-90">اضغط للتسبيح</div>
        </div>
      </button>

      <div className="grid grid-cols-2 gap-3">
        <div className="glass rounded-2xl p-4 text-center">
          <div className="text-xs text-muted-foreground uppercase tracking-widest">المجموع الكلي</div>
          <div className="mt-1 text-2xl font-black text-gold tabular-nums">{total}</div>
        </div>
        <Button variant="outline" onClick={() => setCount(0)} className="h-full border-gold/30 hover:border-gold hover:bg-gold/10">
          <RotateCcw className="ml-2 h-4 w-4" /> إعادة العداد
        </Button>
      </div>
    </div>
  );
}
