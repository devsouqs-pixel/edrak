import { createFileRoute, Link } from "@tanstack/react-router";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { getRank, GRADES, PRESENCE_STATES } from "@/lib/constants";
import { Loader2, Pencil, Save, X, Upload } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { collection, onSnapshot, orderBy, query, where, doc, getDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { uploadFile, compressImage } from "@/lib/upload";
import { toast } from "sonner";

export const Route = createFileRoute("/profile")({
  component: ProfilePage,
  head: () => ({ meta: [{ title: "بروفايلي — إدراك" }] }),
});

function ProfilePage() {
  const { user, userData, updateUserData } = useAuth();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({ displayName: "", username: "", bio: "", grade: "", presence: "online" as any, privacy: "public" as any });
  const [saving, setSaving] = useState(false);
  const [posts, setPosts] = useState<any[]>([]);
  const [followers, setFollowers] = useState<any[]>([]);
  const [followingList, setFollowingList] = useState<any[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (userData) setForm({
      displayName: userData.displayName || "",
      username: userData.username || "",
      bio: userData.bio || "",
      grade: userData.grade || "",
      presence: userData.presence || "online",
      privacy: userData.privacy || "public",
    });
  }, [userData]);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, "posts"), where("uid", "==", user.uid), orderBy("createdAt", "desc"));
    const u1 = onSnapshot(q, (s) => setPosts(s.docs.map((d) => ({ id: d.id, ...d.data() }))));
    const u2 = onSnapshot(collection(db, "users", user.uid, "followers"), async (s) => {
      const items = await Promise.all(s.docs.map(async (d) => {
        const ud = await getDoc(doc(db, "users", d.id));
        return ud.exists() ? { uid: d.id, ...ud.data() } : null;
      }));
      setFollowers(items.filter(Boolean) as any);
    });
    const u3 = onSnapshot(collection(db, "users", user.uid, "following"), async (s) => {
      const items = await Promise.all(s.docs.map(async (d) => {
        const ud = await getDoc(doc(db, "users", d.id));
        return ud.exists() ? { uid: d.id, ...ud.data() } : null;
      }));
      setFollowingList(items.filter(Boolean) as any);
    });
    return () => { u1(); u2(); u3(); };
  }, [user]);

  if (!userData) return <div className="flex min-h-[40vh] items-center justify-center"><Loader2 className="h-6 w-6 animate-spin" /></div>;
  const rank = getRank(userData.points || 0);

  const save = async () => {
    setSaving(true);
    try {
      const uname = form.username.toLowerCase().replace(/[^a-z0-9_]/g, "");
      await updateUserData({ ...form, username: uname });
      setEditing(false);
      toast.success("تم الحفظ");
    } catch (e: any) {
      toast.error("فشل الحفظ", { description: e?.message });
    } finally { setSaving(false); }
  };

  const onPickPhoto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f || !user) return;
    if (f.size > 10 * 1024 * 1024) { toast.error("حجم الصورة كبير جداً (الحد 10MB)"); return; }
    setUploading(true);
    try {
      const compressed = await compressImage(f, 800, 0.88);
      const ext = f.name.split(".").pop() || "jpg";
      const path = `avatars/${user.uid}/${Date.now()}.${ext}`;
      const { url } = await uploadFile(path, compressed, { contentType: "image/jpeg" });
      await updateUserData({ photoURL: url });
      toast.success("تم تحديث الصورة");
    } catch (e: any) {
      toast.error("فشل رفع الصورة", { description: e?.message });
    } finally { setUploading(false); if (fileRef.current) fileRef.current.value = ""; }
  };

  return (
    <div className="mx-auto max-w-3xl px-4 py-6">
      <div className="overflow-hidden rounded-3xl border bg-card shadow-soft">
        <div className="h-32 gradient-primary" />
        <div className="px-6 pb-6">
          <div className="flex items-end justify-between">
            <div className="relative">
              <Avatar className="-mt-12 h-24 w-24 border-4 border-card">
                <AvatarImage src={userData.photoURL} />
                <AvatarFallback>{userData.displayName?.[0]}</AvatarFallback>
              </Avatar>
              <button
                onClick={() => fileRef.current?.click()}
                className="absolute bottom-0 right-0 flex h-7 w-7 items-center justify-center rounded-full bg-primary text-primary-foreground shadow-md hover:opacity-90"
                title="تغيير الصورة"
              >
                {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />}
              </button>
              <input ref={fileRef} type="file" accept="image/*" hidden onChange={onPickPhoto} />
            </div>
            {!editing ? (
              <Button variant="outline" size="sm" onClick={() => setEditing(true)} className="gap-2">
                <Pencil className="h-4 w-4" /> تعديل
              </Button>
            ) : (
              <div className="flex gap-2">
                <Button size="sm" variant="ghost" onClick={() => setEditing(false)}><X className="h-4 w-4" /></Button>
                <Button size="sm" onClick={save} disabled={saving} className="gap-2">
                  {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />} حفظ
                </Button>
              </div>
            )}
          </div>

          {!editing ? (
            <>
              <h1 className="mt-3 text-2xl font-black">{userData.displayName}</h1>
              <p className="text-sm text-muted-foreground">@{userData.username}</p>
              <div className="mt-2 inline-flex items-center gap-2 rounded-full px-3 py-1 text-xs font-semibold" style={{ backgroundColor: `${rank.color}22`, color: rank.color }}>
                {rank.name}
              </div>
              {userData.grade && <p className="mt-2 text-sm text-muted-foreground">الصف: {userData.grade}</p>}
              {userData.bio && <p className="mt-3 whitespace-pre-wrap text-sm">{userData.bio}</p>}
            </>
          ) : (
            <div className="mt-4 space-y-3">
              <div>
                <Label>الاسم الظاهر</Label>
                <Input value={form.displayName} onChange={(e) => setForm({ ...form, displayName: e.target.value })} maxLength={40} />
              </div>
              <div>
                <Label>اسم المستخدم</Label>
                <Input value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })} maxLength={20} dir="ltr" />
              </div>
              <div>
                <Label>نبذة</Label>
                <Textarea value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value.slice(0, 160) })} />
              </div>
              <div className="grid gap-3 sm:grid-cols-3">
                <div>
                  <Label>الصف</Label>
                  <Select value={form.grade} onValueChange={(v) => setForm({ ...form, grade: v })}>
                    <SelectTrigger><SelectValue placeholder="اختر" /></SelectTrigger>
                    <SelectContent>{GRADES.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>الحالة</Label>
                  <Select value={form.presence} onValueChange={(v: any) => setForm({ ...form, presence: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>{PRESENCE_STATES.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>الخصوصية</Label>
                  <Select value={form.privacy} onValueChange={(v: any) => setForm({ ...form, privacy: v })}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="public">عام</SelectItem>
                      <SelectItem value="private">خاص</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          )}

          <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="النقاط" value={userData.points || 0} />
            <Stat label="الجولات" value={userData.completedRounds || 0} />
            <Stat label="ساعات الدراسة" value={Math.round((userData.studyMinutes || 0) / 60)} />
            <Stat label="Streak" value={userData.streak || 0} />
          </div>

          <div className="mt-3 flex justify-around rounded-xl border bg-muted/30 p-3 text-center text-sm">
            <div><div className="font-black">{followers.length}</div><div className="text-xs text-muted-foreground">متابِعون</div></div>
            <div><div className="font-black">{followingList.length}</div><div className="text-xs text-muted-foreground">يتابع</div></div>
            <div><div className="font-black">{posts.length}</div><div className="text-xs text-muted-foreground">منشور</div></div>
          </div>
        </div>
      </div>

      <Tabs defaultValue="posts" className="mt-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="posts">المنشورات</TabsTrigger>
          <TabsTrigger value="followers">المتابِعون</TabsTrigger>
          <TabsTrigger value="following">يتابع</TabsTrigger>
        </TabsList>
        <TabsContent value="posts" className="mt-4 space-y-3">
          {posts.length === 0 && <Empty text="لا منشورات بعد" />}
          {posts.map((p) => (
            <div key={p.id} className="rounded-2xl border bg-card p-4 shadow-soft">
              <p className="whitespace-pre-wrap text-sm">{p.text}</p>
            </div>
          ))}
        </TabsContent>
        <TabsContent value="followers" className="mt-4"><UserList items={followers} /></TabsContent>
        <TabsContent value="following" className="mt-4"><UserList items={followingList} /></TabsContent>
      </Tabs>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number }) {
  return <div className="rounded-xl border bg-muted/30 p-3 text-center"><div className="text-xl font-black text-gradient">{value}</div><div className="text-xs text-muted-foreground">{label}</div></div>;
}
function Empty({ text }: { text: string }) {
  return <div className="rounded-2xl border border-dashed bg-card/50 py-12 text-center text-sm text-muted-foreground">{text}</div>;
}
function UserList({ items }: { items: any[] }) {
  if (items.length === 0) return <Empty text="لا يوجد" />;
  return (
    <div className="space-y-2">
      {items.map((u) => (
        <Link key={u.uid} to="/u/$username" params={{ username: u.username }} className="flex items-center gap-3 rounded-xl border bg-card p-3 hover:bg-muted/50">
          <Avatar className="h-10 w-10"><AvatarImage src={u.photoURL} /><AvatarFallback>{u.displayName?.[0]}</AvatarFallback></Avatar>
          <div><div className="text-sm font-semibold">{u.displayName}</div><div className="text-xs text-muted-foreground">@{u.username}</div></div>
        </Link>
      ))}
    </div>
  );
}
