import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/assistant")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const { messages } = await request.json();
          const apiKey = process.env.GEMINI_API_KEY;
          if (!apiKey) {
            return new Response(JSON.stringify({ error: "GEMINI_API_KEY غير معرّف" }), {
              status: 500, headers: { "Content-Type": "application/json" },
            });
          }
          if (!Array.isArray(messages)) {
            return new Response(JSON.stringify({ error: "messages مطلوبة" }), {
              status: 400, headers: { "Content-Type": "application/json" },
            });
          }

          const systemInstruction = {
            role: "user",
            parts: [{
              text: "أنت Edrak Assistant، مساعد دراسي ذكي لطلاب المدارس في الأردن. أجب باللغة العربية بأسلوب ودود ومختصر، وساعد الطالب في فهم المواد الدراسية، حل الأسئلة، تنظيم وقته، والتحفيز على الدراسة. استخدم الأمثلة عند الحاجة.",
            }],
          };
          const ack = { role: "model", parts: [{ text: "تمام، جاهز لمساعدتك في دراستك." }] };

          const contents = [
            systemInstruction,
            ack,
            ...messages.map((m: any) => ({
              role: m.role === "assistant" ? "model" : "user",
              parts: [{ text: String(m.content || "") }],
            })),
          ];

          const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`;
          const res = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ contents }),
          });

          if (!res.ok) {
            const t = await res.text();
            console.error("Gemini error", res.status, t);
            return new Response(JSON.stringify({ error: "فشل الاتصال بالمساعد" }), {
              status: 500, headers: { "Content-Type": "application/json" },
            });
          }
          const j: any = await res.json();
          const text = j?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join("") || "عذراً، لم أتمكن من توليد رد.";
          return new Response(JSON.stringify({ text }), {
            status: 200, headers: { "Content-Type": "application/json" },
          });
        } catch (e: any) {
          console.error(e);
          return new Response(JSON.stringify({ error: e?.message || "خطأ" }), {
            status: 500, headers: { "Content-Type": "application/json" },
          });
        }
      },
    },
  },
});
