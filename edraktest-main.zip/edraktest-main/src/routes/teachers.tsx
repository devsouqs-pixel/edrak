import { createFileRoute } from "@tanstack/react-router";
import { GraduationCap, ExternalLink, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useState } from "react";

interface Teacher {
  name: string;
  subject: string;
  grade: string;
  description: string;
  link?: string;
  color: string;
}

const TEACHERS: Teacher[] = [
  { name: "أ. محمد العامري", subject: "الرياضيات", grade: "ثاني ثانوي", description: "أحد أبرز معلمي الرياضيات في الأردن، شرح مبسط ومنظم.", color: "#3b82f6" },
  { name: "أ. أحمد الزعبي", subject: "الفيزياء", grade: "ثاني ثانوي", description: "خبرة طويلة في تبسيط الفيزياء وحل المسائل.", color: "#8b5cf6" },
  { name: "أ. ليلى القاضي", subject: "الكيمياء", grade: "ثاني ثانوي", description: "شرح الكيمياء بطريقة عملية وممتعة.", color: "#10b981" },
  { name: "أ. سامي الحوراني", subject: "الأحياء", grade: "ثاني ثانوي", description: "متخصص في الأحياء مع تركيز على الفهم العميق.", color: "#ef4444" },
  { name: "أ. ندى الشريف", subject: "اللغة الإنجليزية", grade: "ثاني ثانوي", description: "تعليم اللغة الإنجليزية بأسلوب حديث وفعّال.", color: "#f59e0b" },
  { name: "أ. ياسين الخطيب", subject: "اللغة العربية", grade: "ثاني ثانوي", description: "خبير في اللغة العربية والقواعد والأدب.", color: "#ec4899" },
  { name: "أ. هبة منصور", subject: "علوم الأرض", grade: "ثاني ثانوي", description: "شرح علوم الأرض بطريقة مرئية وممتعة.", color: "#06b6d4" },
  { name: "أ. رامي الدباس", subject: "التاريخ", grade: "أول ثانوي", description: "أسلوب قصصي شيّق في تدريس التاريخ.", color: "#84cc16" },
];

export const Route = createFileRoute("/teachers")({
  component: TeachersPage,
  head: () => ({ meta: [{ title: "الأساتذة — إدراك" }] }),
});

function TeachersPage() {
  const [q, setQ] = useState("");
  const filtered = TEACHERS.filter((t) =>
    !q || t.name.includes(q) || t.subject.includes(q) || t.grade.includes(q)
  );

  return (
    <div className="mx-auto max-w-5xl space-y-6 px-4 py-6">
      <div>
        <h1 className="text-3xl font-black">الأساتذة</h1>
        <p className="mt-1 text-sm text-muted-foreground">نخبة من أفضل المعلمين في الأردن</p>
      </div>

      <div className="relative max-w-md">
        <Search className="absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input placeholder="ابحث عن أستاذ أو مادة..." value={q} onChange={(e) => setQ(e.target.value)} className="pr-9" />
      </div>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((t, i) => (
          <div key={i} className="group rounded-2xl border bg-card p-5 shadow-soft transition-all hover:shadow-glow">
            <div className="flex items-start gap-3">
              <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl text-white" style={{ background: t.color }}>
                <GraduationCap className="h-6 w-6" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="font-black">{t.name}</div>
                <div className="text-xs text-muted-foreground">{t.subject} • {t.grade}</div>
              </div>
            </div>
            <p className="mt-3 text-sm text-muted-foreground">{t.description}</p>
            {t.link && (
              <a href={t.link} target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-1 text-xs text-primary hover:underline">
                زيارة الصفحة <ExternalLink className="h-3 w-3" />
              </a>
            )}
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="rounded-2xl border border-dashed p-10 text-center text-sm text-muted-foreground">
          لا توجد نتائج
        </div>
      )}
    </div>
  );
}
