import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { onAuthStateChanged, signInWithPopup, signOut, type User } from "firebase/auth";
import { doc, getDoc, setDoc, serverTimestamp, updateDoc } from "firebase/firestore";
import { auth, db, googleProvider } from "@/lib/firebase";

export interface UserData {
  uid: string;
  displayName: string;
  username: string;
  email: string;
  photoURL: string;
  bio: string;
  grade: string;
  points: number;
  streak: number;
  studyMinutes: number;
  completedRounds: number;
  presence: "online" | "busy" | "away" | "sleep";
  privacy: "public" | "private";
  isAdmin?: boolean;
  createdAt?: any;
  lastActive?: any;
  followers?: number;
  following?: number;
}

interface AuthCtx {
  user: User | null;
  userData: UserData | null;
  loading: boolean;
  signInGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  refreshUserData: () => Promise<void>;
  updateUserData: (patch: Partial<UserData>) => Promise<void>;
}

const Ctx = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchUserData = async (u: User) => {
    const ref = doc(db, "users", u.uid);
    const snap = await getDoc(ref);
    if (!snap.exists()) {
      const fresh: UserData = {
        uid: u.uid,
        displayName: u.displayName || "مستخدم",
        username: (u.email?.split("@")[0] || `user${Date.now()}`).toLowerCase().replace(/[^a-z0-9_]/g, ""),
        email: u.email || "",
        photoURL: u.photoURL || "",
        bio: "",
        grade: "",
        points: 0,
        streak: 0,
        studyMinutes: 0,
        completedRounds: 0,
        presence: "online",
        privacy: "public",
        followers: 0,
        following: 0,
      };
      await setDoc(ref, { ...fresh, createdAt: serverTimestamp(), lastActive: serverTimestamp() });
      setUserData(fresh);
    } else {
      const data = snap.data() as UserData;
      setUserData({ ...data, uid: u.uid });
      await updateDoc(ref, { lastActive: serverTimestamp() }).catch(() => {});
    }
  };

  useEffect(() => {
    if (!auth) return;
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      if (u) await fetchUserData(u);
      else setUserData(null);
      setLoading(false);
    });
    return unsub;
  }, []);

  const signInGoogle = async () => {
    await signInWithPopup(auth, googleProvider);
  };

  const logout = async () => {
    await signOut(auth);
  };

  const refreshUserData = async () => {
    if (user) await fetchUserData(user);
  };

  const updateUserData = async (patch: Partial<UserData>) => {
    if (!user) return;
    await updateDoc(doc(db, "users", user.uid), patch as any);
    setUserData((prev) => (prev ? { ...prev, ...patch } : prev));
  };

  return (
    <Ctx.Provider value={{ user, userData, loading, signInGoogle, logout, refreshUserData, updateUserData }}>
      {children}
    </Ctx.Provider>
  );
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth must be used within AuthProvider");
  return c;
}
