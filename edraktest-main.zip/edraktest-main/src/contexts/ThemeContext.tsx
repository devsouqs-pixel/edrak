import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { applyTheme, loadTheme, saveTheme } from "@/lib/theme";

interface ThemeCtx {
  mode: "light" | "dark";
  color: string;
  setMode: (m: "light" | "dark") => void;
  setColor: (c: string) => void;
}

const Ctx = createContext<ThemeCtx | null>(null);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [mode, setModeState] = useState<"light" | "dark">("light");
  const [color, setColorState] = useState("default");

  useEffect(() => {
    const t = loadTheme();
    setModeState(t.mode);
    setColorState(t.color);
    applyTheme(t.mode, t.color);
  }, []);

  const setMode = (m: "light" | "dark") => { setModeState(m); applyTheme(m, color); saveTheme(m, color); };
  const setColor = (c: string) => { setColorState(c); applyTheme(mode, c); saveTheme(mode, c); };

  return <Ctx.Provider value={{ mode, color, setMode, setColor }}>{children}</Ctx.Provider>;
}

export function useTheme() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useTheme must be used within ThemeProvider");
  return c;
}
