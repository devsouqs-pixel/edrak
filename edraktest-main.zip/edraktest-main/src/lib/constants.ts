export const GRADES = [
  "ثاني ثانوي",
  "أول ثانوي",
  "عاشر",
  "تاسع",
  "ثامن",
  "سابع",
  "سادس",
  "خامس",
  "رابع",
  "ثالث",
  "ثاني",
  "أول",
] as const;

export type Grade = typeof GRADES[number];

export const SUBJECTS_BY_GRADE: Record<string, string[]> = {
  "ثاني ثانوي": [
    "كيمياء", "أحياء", "لغة إنجليزية متقدم", "لغة عربية تخصص",
    "تربية إسلامية تخصص", "ثقافة مالية", "علوم أرض", "فلسفة",
    "فيزياء", "رياضيات", "رياضيات أعمال", "علوم نفس واجتماع",
    "جغرافيا", "تاريخ",
  ],
  "أول ثانوي": [
    "تاريخ الأردن", "اللغة العربية", "اللغة الإنجليزية", "التربية الإسلامية",
  ],
};

const BELOW_TENTH = [
  "اللغة العربية", "اللغة الإنجليزية", "الرياضيات", "العلوم",
  "التاريخ", "الجغرافيا", "التربية الإسلامية", "الحاسوب", "التربية الوطنية",
];

["عاشر", "تاسع", "ثامن", "سابع", "سادس", "خامس", "رابع", "ثالث", "ثاني", "أول"].forEach((g) => {
  SUBJECTS_BY_GRADE[g] = BELOW_TENTH;
});

export const FILE_GRADES = ["ثاني ثانوي", "أول ثانوي", "عاشر فما دون"] as const;

export const RANKS = [
  { name: "طازة", min: 0, color: "#94a3b8" },
  { name: "مبتدئ", min: 50, color: "#60a5fa" },
  { name: "حريف", min: 300, color: "#34d399" },
  { name: "نيرد", min: 1000, color: "#a78bfa" },
  { name: "معه ماجيستير", min: 2000, color: "#f59e0b" },
  { name: "دكتور دراسي", min: 5000, color: "#ef4444" },
] as const;

export function getRank(points: number): { name: string; min: number; color: string } {
  let r: { name: string; min: number; color: string } = RANKS[0];
  for (const x of RANKS) if (points >= x.min) r = x;
  return r;
}

export const POINTS = {
  COMPLETE_ROUND: 3,
  CHAT_MESSAGE: 1,
  POST: 2,
  FOLLOW: 2,
  UPLOAD_FILE: 5,
  CHAT_COOLDOWN_MS: 10_000,
};

export const COLOR_PRESETS = [
  { name: "إدراك", value: "default", primary: "262 83% 58%" },
  { name: "أزرق", value: "blue", primary: "217 91% 60%" },
  { name: "أخضر", value: "green", primary: "142 71% 45%" },
  { name: "أزرق داكن", value: "navy", primary: "222 47% 35%" },
  { name: "بنفسجي", value: "purple", primary: "271 81% 56%" },
  { name: "أحمر", value: "red", primary: "0 84% 60%" },
  { name: "برتقالي", value: "orange", primary: "25 95% 53%" },
];

export const PRESENCE_STATES = [
  { value: "online", label: "متصل", color: "#22c55e" },
  { value: "busy", label: "مشغول", color: "#ef4444" },
  { value: "away", label: "بعيد", color: "#f59e0b" },
  { value: "sleep", label: "نائم", color: "#6366f1" },
] as const;
