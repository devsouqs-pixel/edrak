import { ref as sref, uploadBytesResumable, getDownloadURL } from "firebase/storage";
import { storage } from "./firebase";

export interface UploadOptions {
  onProgress?: (pct: number) => void;
  contentType?: string;
}

/**
 * Upload a file to Firebase Storage with clear Arabic error messages.
 * Returns { url, path } on success.
 */
export async function uploadFile(
  path: string,
  file: File | Blob,
  opts: UploadOptions = {}
): Promise<{ url: string; path: string }> {
  if (!storage) throw new Error("التخزين غير مهيأ");

  const r = sref(storage, path);
  const metadata = opts.contentType ? { contentType: opts.contentType } : undefined;

  return new Promise((resolve, reject) => {
    const task = uploadBytesResumable(r, file, metadata);
    task.on(
      "state_changed",
      (snap) => {
        if (opts.onProgress) {
          const pct = (snap.bytesTransferred / snap.totalBytes) * 100;
          opts.onProgress(Math.round(pct));
        }
      },
      (err: any) => {
        const code = err?.code || "";
        let msg = err?.message || "فشل الرفع";
        if (code.includes("unauthorized") || code.includes("permission-denied")) {
          msg = "ليس لديك صلاحية الرفع. تحقق من قواعد Storage في Firebase.";
        } else if (code.includes("canceled")) {
          msg = "تم إلغاء الرفع";
        } else if (code.includes("retry-limit-exceeded") || code.includes("network")) {
          msg = "فشل الاتصال بالتخزين. تحقق من قواعد CORS وقواعد Storage.";
        } else if (code.includes("quota-exceeded")) {
          msg = "تجاوزت الحد المتاح للتخزين";
        } else if (code.includes("invalid-argument")) {
          msg = "ملف غير صالح";
        }
        const e: any = new Error(msg);
        e.code = code;
        reject(e);
      },
      async () => {
        try {
          const url = await getDownloadURL(task.snapshot.ref);
          resolve({ url, path });
        } catch (err: any) {
          reject(new Error(err?.message || "تعذر الحصول على رابط الملف"));
        }
      }
    );
  });
}

/** Compress an image to a reasonable size before upload (browser-only). */
export async function compressImage(
  file: File,
  maxSize = 1024,
  quality = 0.85
): Promise<Blob> {
  if (!file.type.startsWith("image/")) return file;
  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      let { width, height } = img;
      if (width > maxSize || height > maxSize) {
        const ratio = width / height;
        if (ratio > 1) { width = maxSize; height = Math.round(maxSize / ratio); }
        else { height = maxSize; width = Math.round(maxSize * ratio); }
      }
      const canvas = document.createElement("canvas");
      canvas.width = width; canvas.height = height;
      const ctx = canvas.getContext("2d");
      if (!ctx) { URL.revokeObjectURL(url); return resolve(file); }
      ctx.drawImage(img, 0, 0, width, height);
      canvas.toBlob(
        (blob) => {
          URL.revokeObjectURL(url);
          if (blob) resolve(blob); else resolve(file);
        },
        "image/jpeg",
        quality
      );
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("تعذر قراءة الصورة")); };
    img.src = url;
  });
}
