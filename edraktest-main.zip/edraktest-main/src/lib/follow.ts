import {
  doc, getDoc, setDoc, deleteDoc, increment, updateDoc, collection,
  query, where, getDocs, limit,
} from "firebase/firestore";
import { db } from "./firebase";
import { awardPoints } from "./points";
import { POINTS } from "./constants";

export async function followUser(meUid: string, targetUid: string) {
  if (!meUid || !targetUid || meUid === targetUid) return;
  const meFollowing = doc(db, "users", meUid, "following", targetUid);
  const exists = await getDoc(meFollowing);
  if (exists.exists()) return;

  await setDoc(meFollowing, { uid: targetUid, createdAt: Date.now() });
  await setDoc(doc(db, "users", targetUid, "followers", meUid), { uid: meUid, createdAt: Date.now() });
  await updateDoc(doc(db, "users", meUid), { following: increment(1) }).catch(() => {});
  await updateDoc(doc(db, "users", targetUid), { followers: increment(1) }).catch(() => {});
  await awardPoints(meUid, POINTS.FOLLOW);
}

export async function unfollowUser(meUid: string, targetUid: string) {
  if (!meUid || !targetUid) return;
  const meFollowing = doc(db, "users", meUid, "following", targetUid);
  const exists = await getDoc(meFollowing);
  if (!exists.exists()) return;

  await deleteDoc(meFollowing);
  await deleteDoc(doc(db, "users", targetUid, "followers", meUid));
  await updateDoc(doc(db, "users", meUid), { following: increment(-1) }).catch(() => {});
  await updateDoc(doc(db, "users", targetUid), { followers: increment(-1) }).catch(() => {});
}

export async function isFollowing(meUid: string, targetUid: string) {
  if (!meUid || !targetUid) return false;
  const snap = await getDoc(doc(db, "users", meUid, "following", targetUid));
  return snap.exists();
}

export async function findUserByUsername(username: string) {
  const q = query(collection(db, "users"), where("username", "==", username.toLowerCase()), limit(1));
  const snap = await getDocs(q);
  if (snap.empty) return null;
  const d = snap.docs[0];
  return { uid: d.id, ...(d.data() as any) };
}
