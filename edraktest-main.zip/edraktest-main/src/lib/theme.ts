// Dark Royal theme — single elegant theme with optional light variant
const KEY_MODE = "edrak.mode";

export function loadTheme(): { mode: "light" | "dark"; color: string } {
  if (typeof window === "undefined") return { mode: "dark", color: "gold" };
  const mode = (localStorage.getItem(KEY_MODE) as "light" | "dark") || "dark";
  return { mode, color: "gold" };
}

export function saveTheme(mode: "light" | "dark", _color: string) {
  if (typeof window === "undefined") return;
  localStorage.setItem(KEY_MODE, mode);
}

export function applyTheme(mode: "light" | "dark", _color: string) {
  if (typeof document === "undefined") return;
  const root = document.documentElement;
  root.classList.remove("light", "dark");
  root.classList.add(mode);
  root.style.colorScheme = mode;
}
