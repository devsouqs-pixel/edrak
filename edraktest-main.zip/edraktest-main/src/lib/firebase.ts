import { initializeApp, getApps, getApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getDatabase } from "firebase/database";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyAS2D-G1FHQJt1wmU3OKYJuTCLc-BD-UEQ",
  authDomain: "edrakjor.firebaseapp.com",
  projectId: "edrakjor",
  storageBucket: "edrakjor.firebasestorage.app",
  messagingSenderId: "471939372230",
  appId: "1:471939372230:web:b97b22ba182e69f09e73c7",
  databaseURL: "https://edrakjor-default-rtdb.firebaseio.com",
};

export const app = getApps().length ? getApp() : initializeApp(firebaseConfig);
export const auth = typeof window !== "undefined" ? getAuth(app) : null as any;
export const db = typeof window !== "undefined" ? getFirestore(app) : null as any;
export const rtdb = typeof window !== "undefined" ? getDatabase(app) : null as any;
export const storage = typeof window !== "undefined" ? getStorage(app) : null as any;
export const googleProvider = new GoogleAuthProvider();
