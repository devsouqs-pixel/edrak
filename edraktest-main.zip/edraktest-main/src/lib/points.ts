import { doc, increment, updateDoc } from "firebase/firestore";
import { db } from "./firebase";

export async function awardPoints(uid: string, amount: number, extra: Record<string, any> = {}) {
  if (!uid || !amount) return;
  await updateDoc(doc(db, "users", uid), { points: increment(amount), ...extra }).catch(() => {});
}
