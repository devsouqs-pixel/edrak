import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/contexts/AuthContext";
import { followUser, unfollowUser, isFollowing } from "@/lib/follow";
import { UserPlus, UserCheck, Loader2 } from "lucide-react";
import { toast } from "sonner";

export function FollowButton({ targetUid, className }: { targetUid: string; className?: string }) {
  const { user } = useAuth();
  const [following, setFollowing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!user || user.uid === targetUid) { setLoading(false); return; }
    isFollowing(user.uid, targetUid).then((r) => { setFollowing(r); setLoading(false); });
  }, [user, targetUid]);

  if (!user || user.uid === targetUid) return null;
  if (loading) return <Button size="sm" variant="outline" disabled className={className}><Loader2 className="h-4 w-4 animate-spin" /></Button>;

  const toggle = async () => {
    setBusy(true);
    try {
      if (following) {
        await unfollowUser(user.uid, targetUid);
        setFollowing(false);
        toast.success("تم إلغاء المتابعة");
      } else {
        await followUser(user.uid, targetUid);
        setFollowing(true);
        toast.success("تمت المتابعة +2 نقاط");
      }
    } catch (e: any) {
      toast.error("خطأ", { description: e?.message });
    } finally { setBusy(false); }
  };

  return (
    <Button size="sm" variant={following ? "outline" : "default"} onClick={toggle} disabled={busy} className={`gap-2 ${className || ""}`}>
      {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : following ? <UserCheck className="h-4 w-4" /> : <UserPlus className="h-4 w-4" />}
      {following ? "متابَع" : "متابعة"}
    </Button>
  );
}
