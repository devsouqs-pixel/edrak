import { useEffect, useState } from "react";
import {
  collection, addDoc, serverTimestamp, query, orderBy, onSnapshot,
  doc, deleteDoc, updateDoc, increment, getDoc, setDoc, where,
} from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Heart, MessageCircle, Bookmark, Trash2, Pencil, Send, Loader2, Check, X } from "lucide-react";
import { toast } from "sonner";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { awardPoints } from "@/lib/points";
import { POINTS } from "@/lib/constants";
import { formatRelative } from "@/lib/time";
import { Link } from "@tanstack/react-router";

interface Post {
  id: string;
  uid: string;
  authorName: string;
  authorUsername?: string;
  authorPhoto: string;
  text: string;
  likes: string[];
  saves: string[];
  commentsCount: number;
  createdAt: any;
  edited?: boolean;
}

export function FeedPage() {
  const { user, userData } = useAuth();
  const [text, setText] = useState("");
  const [posts, setPosts] = useState<Post[]>([]);
  const [following, setFollowing] = useState<string[]>([]);
  const [tab, setTab] = useState<"foryou" | "following">("foryou");
  const [posting, setPosting] = useState(false);

  useEffect(() => {
    const q = query(collection(db, "posts"), orderBy("createdAt", "desc"));
    const unsub = onSnapshot(q, (snap) => {
      setPosts(snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) })));
    });
    return unsub;
  }, []);

  useEffect(() => {
    if (!user) return;
    const unsub = onSnapshot(collection(db, "users", user.uid, "following"), (snap) => {
      setFollowing(snap.docs.map((d) => d.id));
    });
    return unsub;
  }, [user]);

  const submit = async () => {
    if (!user || !userData || !text.trim() || posting) return;
    setPosting(true);
    try {
      await addDoc(collection(db, "posts"), {
        uid: user.uid,
        authorName: userData.displayName,
        authorUsername: userData.username,
        authorPhoto: userData.photoURL,
        text: text.trim(),
        likes: [],
        saves: [],
        commentsCount: 0,
        createdAt: serverTimestamp(),
      });
      await awardPoints(user.uid, POINTS.POST);
      setText("");
      toast.success("تم نشر المنشور +2 نقاط");
    } catch (e: any) {
      toast.error("فشل النشر", { description: e?.message });
    } finally { setPosting(false); }
  };

  const visible = tab === "following" ? posts.filter((p) => following.includes(p.uid) || p.uid === user?.uid) : posts;

  return (
    <div className="mx-auto max-w-2xl px-4 py-6">
      <div className="mb-6 rounded-2xl border bg-card p-4 shadow-soft">
        <div className="flex gap-3">
          <Avatar className="h-10 w-10">
            <AvatarImage src={userData?.photoURL} />
            <AvatarFallback>{userData?.displayName?.[0] || "؟"}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <Textarea
              placeholder="شو في بالك اليوم؟"
              value={text}
              onChange={(e) => setText(e.target.value.slice(0, 500))}
              className="min-h-[80px] resize-none border-0 bg-transparent text-base focus-visible:ring-0"
            />
            <div className="mt-2 flex items-center justify-between">
              <span className="text-xs text-muted-foreground">{text.length}/500</span>
              <Button onClick={submit} disabled={!text.trim() || posting} size="sm" className="gap-2">
                {posting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                نشر
              </Button>
            </div>
          </div>
        </div>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
        <TabsList className="mb-4 grid w-full grid-cols-2">
          <TabsTrigger value="foryou">For You</TabsTrigger>
          <TabsTrigger value="following">Following</TabsTrigger>
        </TabsList>
        <TabsContent value={tab}>
          <div className="space-y-3">
            {visible.length === 0 && (
              <div className="rounded-2xl border border-dashed bg-card/50 py-12 text-center text-sm text-muted-foreground">
                لا توجد منشورات بعد
              </div>
            )}
            {visible.map((p) => <PostCard key={p.id} post={p} />)}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

function PostCard({ post }: { post: Post }) {
  const { user, userData } = useAuth();
  const [editing, setEditing] = useState(false);
  const [editText, setEditText] = useState(post.text);
  const [showComments, setShowComments] = useState(false);
  const liked = !!user && (post.likes || []).includes(user.uid);
  const saved = !!user && (post.saves || []).includes(user.uid);
  const isOwner = user?.uid === post.uid;

  const toggleLike = async () => {
    if (!user) return;
    const ref = doc(db, "posts", post.id);
    const snap = await getDoc(ref);
    if (!snap.exists()) return;
    const arr: string[] = snap.data().likes || [];
    const next = arr.includes(user.uid) ? arr.filter((x) => x !== user.uid) : [...arr, user.uid];
    await updateDoc(ref, { likes: next });
  };
  const toggleSave = async () => {
    if (!user) return;
    const ref = doc(db, "posts", post.id);
    const snap = await getDoc(ref);
    if (!snap.exists()) return;
    const arr: string[] = snap.data().saves || [];
    const next = arr.includes(user.uid) ? arr.filter((x) => x !== user.uid) : [...arr, user.uid];
    await updateDoc(ref, { saves: next });
  };
  const remove = async () => {
    if (!confirm("حذف المنشور؟")) return;
    await deleteDoc(doc(db, "posts", post.id));
    toast.success("تم الحذف");
  };
  const saveEdit = async () => {
    if (!editText.trim()) return;
    await updateDoc(doc(db, "posts", post.id), { text: editText.trim(), edited: true });
    setEditing(false);
    toast.success("تم التعديل");
  };

  return (
    <div className="rounded-2xl border bg-card p-4 shadow-soft transition hover:shadow-md">
      <div className="flex items-start justify-between gap-3">
        {post.authorUsername ? (
          <Link to="/u/$username" params={{ username: post.authorUsername }} className="flex items-center gap-3 hover:opacity-80">
            <Avatar className="h-10 w-10">
              <AvatarImage src={post.authorPhoto} />
              <AvatarFallback>{post.authorName?.[0] || "؟"}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-2 text-sm font-semibold">
                {post.authorName}
                {post.edited && <span className="text-xs font-normal text-muted-foreground">(تم التعديل)</span>}
              </div>
              <div className="text-xs text-muted-foreground">{formatRelative(post.createdAt)}</div>
            </div>
          </Link>
        ) : (
          <div className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={post.authorPhoto} />
              <AvatarFallback>{post.authorName?.[0] || "؟"}</AvatarFallback>
            </Avatar>
            <div>
              <div className="flex items-center gap-2 text-sm font-semibold">
                {post.authorName}
                {post.edited && <span className="text-xs font-normal text-muted-foreground">(تم التعديل)</span>}
              </div>
              <div className="text-xs text-muted-foreground">{formatRelative(post.createdAt)}</div>
            </div>
          </div>
        )}
        {isOwner && !editing && (
          <div className="flex gap-1">
            <Button variant="ghost" size="icon" onClick={() => { setEditing(true); setEditText(post.text); }}>
              <Pencil className="h-4 w-4" />
            </Button>
            <Button variant="ghost" size="icon" onClick={remove} className="text-destructive">
              <Trash2 className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>

      {editing ? (
        <div className="mt-3">
          <Textarea value={editText} onChange={(e) => setEditText(e.target.value.slice(0, 500))} />
          <div className="mt-2 flex justify-end gap-2">
            <Button size="sm" variant="ghost" onClick={() => setEditing(false)}><X className="h-4 w-4" /></Button>
            <Button size="sm" onClick={saveEdit}><Check className="h-4 w-4" /></Button>
          </div>
        </div>
      ) : (
        <p className="mt-3 whitespace-pre-wrap text-[15px] leading-relaxed">{post.text}</p>
      )}

      <div className="mt-4 flex items-center gap-1 text-muted-foreground">
        <Button variant="ghost" size="sm" onClick={toggleLike} className={`gap-2 ${liked ? "text-rose-500" : ""}`}>
          <Heart className={`h-4 w-4 ${liked ? "fill-current" : ""}`} />
          {(post.likes || []).length || ""}
        </Button>
        <Button variant="ghost" size="sm" onClick={() => setShowComments((v) => !v)} className="gap-2">
          <MessageCircle className="h-4 w-4" />
          {post.commentsCount || ""}
        </Button>
        <Button variant="ghost" size="sm" onClick={toggleSave} className={`gap-2 ${saved ? "text-primary" : ""}`}>
          <Bookmark className={`h-4 w-4 ${saved ? "fill-current" : ""}`} />
        </Button>
      </div>

      {showComments && <Comments postId={post.id} />}
    </div>
  );
}

interface Comment { id: string; uid: string; name: string; photo: string; text: string; createdAt: any; edited?: boolean; }

function Comments({ postId }: { postId: string }) {
  const { user, userData } = useAuth();
  const [comments, setComments] = useState<Comment[]>([]);
  const [text, setText] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");

  useEffect(() => {
    const q = query(collection(db, "posts", postId, "comments"), orderBy("createdAt", "asc"));
    return onSnapshot(q, (snap) => setComments(snap.docs.map((d) => ({ id: d.id, ...(d.data() as any) }))));
  }, [postId]);

  const send = async () => {
    if (!user || !userData || !text.trim()) return;
    await addDoc(collection(db, "posts", postId, "comments"), {
      uid: user.uid, name: userData.displayName, photo: userData.photoURL,
      text: text.trim(), createdAt: serverTimestamp(),
    });
    await updateDoc(doc(db, "posts", postId), { commentsCount: increment(1) });
    setText("");
  };
  const remove = async (id: string) => {
    await deleteDoc(doc(db, "posts", postId, "comments", id));
    await updateDoc(doc(db, "posts", postId), { commentsCount: increment(-1) });
  };
  const saveEdit = async (id: string) => {
    if (!editText.trim()) return;
    await updateDoc(doc(db, "posts", postId, "comments", id), { text: editText.trim(), edited: true });
    setEditingId(null);
  };

  return (
    <div className="mt-4 space-y-2 border-t pt-3">
      {comments.map((c) => (
        <div key={c.id} className="flex items-start gap-2">
          <Avatar className="h-7 w-7"><AvatarImage src={c.photo} /><AvatarFallback>{c.name?.[0]}</AvatarFallback></Avatar>
          <div className="flex-1 rounded-2xl bg-muted px-3 py-2">
            <div className="flex items-center justify-between gap-2">
              <span className="text-xs font-semibold">{c.name}</span>
              {c.uid === user?.uid && editingId !== c.id && (
                <div className="flex gap-1">
                  <button onClick={() => { setEditingId(c.id); setEditText(c.text); }} className="text-xs text-muted-foreground hover:text-foreground">تعديل</button>
                  <button onClick={() => remove(c.id)} className="text-xs text-destructive">حذف</button>
                </div>
              )}
            </div>
            {editingId === c.id ? (
              <div className="mt-1 flex gap-1">
                <Textarea value={editText} onChange={(e) => setEditText(e.target.value)} className="min-h-[40px] text-sm" />
                <Button size="icon" variant="ghost" onClick={() => saveEdit(c.id)}><Check className="h-3 w-3" /></Button>
              </div>
            ) : (
              <p className="text-sm">{c.text} {c.edited && <span className="text-xs text-muted-foreground">(تم التعديل)</span>}</p>
            )}
          </div>
        </div>
      ))}
      <div className="flex gap-2">
        <Textarea value={text} onChange={(e) => setText(e.target.value.slice(0, 300))} placeholder="اكتب تعليق..." className="min-h-[40px] text-sm" />
        <Button size="icon" onClick={send} disabled={!text.trim()}><Send className="h-4 w-4" /></Button>
      </div>
    </div>
  );
}
