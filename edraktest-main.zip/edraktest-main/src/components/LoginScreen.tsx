import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Sparkles, Loader2, BookOpen, Users, Trophy, Moon } from "lucide-react";
import { toast } from "sonner";

export function LoginScreen() {
  const { signInGoogle } = useAuth();
  const [loading, setLoading] = useState(false);

  const handleGoogle = async () => {
    setLoading(true);
    try { await signInGoogle(); }
    catch (e: any) { toast.error("فشل تسجيل الدخول", { description: e?.message }); }
    finally { setLoading(false); }
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden p-4" dir="rtl">
      {/* Aurora background */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 right-1/4 h-[500px] w-[500px] rounded-full bg-gold/20 blur-[120px] animate-pulse" />
        <div className="absolute bottom-0 left-1/4 h-[500px] w-[500px] rounded-full bg-gold-glow/15 blur-[120px] animate-pulse" style={{ animationDelay: "1s" }} />
        <div className="absolute top-1/3 left-1/3 h-[300px] w-[300px] rounded-full bg-amber-500/10 blur-[100px]" />
      </div>

      {/* Decorative gold dots */}
      <div className="absolute inset-0 -z-10 opacity-30 [background-image:radial-gradient(hsl(var(--gold))_1px,transparent_1px)] [background-size:32px_32px]" />

      <div className="w-full max-w-md">
        <div className="glass-strong rounded-[28px] p-10 shadow-gold relative overflow-hidden">
          {/* shimmer top */}
          <div className="absolute inset-x-0 top-0 h-px gradient-gold opacity-70" />

          <div className="flex flex-col items-center text-center">
            <div className="relative mb-8">
              <div className="absolute inset-0 gradient-gold blur-2xl opacity-50 animate-glow rounded-full" />
              <div className="relative flex h-20 w-20 items-center justify-center rounded-2xl gradient-gold shadow-gold">
                <Sparkles className="h-10 w-10 text-background" strokeWidth={2.5} />
              </div>
            </div>

            <h1 className="text-5xl font-black text-gradient tracking-tight">إدراك</h1>
            <div className="mt-1 text-xs tracking-[0.3em] text-gold/80 font-bold">EDRAK • PREMIUM</div>
            <p className="mt-4 text-sm text-muted-foreground leading-relaxed max-w-xs">
              منصة الدراسة الجماعية الفاخرة. ادرس مع أصدقائك، تنافس على المتصدرين، وارتقِ في رحلتك التعليمية.
            </p>

            {/* Features */}
            <div className="my-7 grid grid-cols-4 gap-2 w-full">
              {[
                { icon: Users, label: "جولات" },
                { icon: BookOpen, label: "ملفات" },
                { icon: Trophy, label: "تنافس" },
                { icon: Moon, label: "ديني" },
              ].map((f, i) => (
                <div key={i} className="glass-subtle rounded-xl p-2.5 flex flex-col items-center gap-1">
                  <f.icon className="h-4 w-4 text-gold" />
                  <span className="text-[10px] text-muted-foreground">{f.label}</span>
                </div>
              ))}
            </div>

            <Button
              onClick={handleGoogle}
              disabled={loading}
              size="lg"
              className="w-full gap-3 text-base h-12 bg-foreground text-background hover:bg-foreground/90 font-bold"
            >
              {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : (
                <svg className="h-5 w-5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
              )}
              متابعة بحساب Google
            </Button>

            <p className="mt-6 text-[11px] text-muted-foreground">
              بتسجيلك توافق على شروط الاستخدام الخاصة بإدراك
            </p>
          </div>
        </div>

        <p className="mt-6 text-center text-xs text-muted-foreground">
          © 2026 إدراك — صُنع بفخر في الأردن 🇯🇴
        </p>
      </div>
    </div>
  );
}
