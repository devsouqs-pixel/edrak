import type { ReactNode } from "react";
import { Link, useRouterState, useNavigate } from "@tanstack/react-router";
import {
  Home, Search, Trophy, FileText, GraduationCap, User, Bot,
  Moon, Settings, Activity, LogOut, Sun, Sparkles, Plus,
  Bell, Command, Shield,
} from "lucide-react";
import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useTheme } from "@/contexts/ThemeContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  CommandDialog, CommandEmpty, CommandGroup, CommandInput,
  CommandItem, CommandList,
} from "@/components/ui/command";
import { getRank } from "@/lib/constants";

const NAV_PRIMARY = [
  { title: "الرئيسية", url: "/", icon: Home },
  { title: "الجولات", url: "/rooms", icon: Search },
  { title: "الملفات", url: "/files", icon: FileText },
  { title: "المتصدرون", url: "/leaderboard", icon: Trophy },
  { title: "الديني", url: "/islamic", icon: Moon },
];

const NAV_SECONDARY = [
  { title: "الأساتذة", url: "/teachers", icon: GraduationCap },
  { title: "Edrak Assistant", url: "/assistant", icon: Bot },
  { title: "نشاطي", url: "/activity", icon: Activity },
  { title: "الإعدادات", url: "/settings", icon: Settings },
];

const NAV_ALL = [...NAV_PRIMARY, ...NAV_SECONDARY, { title: "بروفايلي", url: "/profile", icon: User }];

function isActive(path: string, url: string) {
  return url === "/" ? path === "/" : path.startsWith(url);
}

function TopNav({ onOpenCommand }: { onOpenCommand: () => void }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { mode, setMode } = useTheme();
  const { logout, userData } = useAuth();
  const rank = getRank(userData?.points || 0);

  return (
    <header className="sticky top-0 z-40 hidden md:block">
      <div className="border-b border-gold/20 bg-background/60 backdrop-blur-2xl">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-6">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2.5 shrink-0">
            <div className="relative flex h-10 w-10 items-center justify-center rounded-xl gradient-gold shadow-gold">
              <Sparkles className="h-5 w-5 text-background" />
            </div>
            <div>
              <div className="text-lg font-black text-gradient leading-none">إدراك</div>
              <div className="text-[10px] text-muted-foreground mt-0.5">Edrak</div>
            </div>
          </Link>

          {/* Primary nav */}
          <nav className="flex items-center gap-1 mx-auto">
            {NAV_PRIMARY.map((item) => {
              const active = isActive(path, item.url);
              return (
                <Link
                  key={item.url}
                  to={item.url}
                  className={`relative flex items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-semibold transition-all ${
                    active
                      ? "text-gold bg-gold/10"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted/50"
                  }`}
                >
                  <item.icon className="h-4 w-4" />
                  <span>{item.title}</span>
                  {active && (
                    <span className="absolute inset-x-3 -bottom-[17px] h-0.5 rounded-full gradient-gold" />
                  )}
                </Link>
              );
            })}
          </nav>

          {/* Right cluster */}
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={onOpenCommand}
              className="gap-2 text-muted-foreground hover:text-foreground"
            >
              <Command className="h-3.5 w-3.5" />
              <span className="text-xs">بحث</span>
              <kbd className="hidden lg:inline rounded border border-gold/20 bg-muted/40 px-1.5 py-0.5 text-[10px] font-mono">⌘K</kbd>
            </Button>

            <Button variant="ghost" size="icon" onClick={() => setMode(mode === "dark" ? "light" : "dark")}>
              {mode === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 rounded-xl border border-gold/20 bg-card/40 p-1 pr-2.5 hover:bg-card/70 transition">
                  <div className="text-right hidden lg:block">
                    <div className="text-xs font-bold leading-tight">{userData?.displayName}</div>
                    <div className="text-[10px] text-gold">{rank.name} • {userData?.points || 0}</div>
                  </div>
                  <Avatar className="h-8 w-8 border border-gold/30">
                    <AvatarImage src={userData?.photoURL} />
                    <AvatarFallback className="bg-gold/20 text-gold text-xs">
                      {userData?.displayName?.[0]}
                    </AvatarFallback>
                  </Avatar>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="glass-strong w-56">
                <DropdownMenuLabel className="font-black text-gradient">{userData?.displayName}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {NAV_SECONDARY.map((it) => (
                  <DropdownMenuItem key={it.url} asChild>
                    <Link to={it.url} className="gap-2">
                      <it.icon className="h-4 w-4" /> {it.title}
                    </Link>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuItem asChild>
                  <Link to="/profile" className="gap-2">
                    <User className="h-4 w-4" /> بروفايلي
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={logout} className="gap-2 text-destructive focus:text-destructive">
                  <LogOut className="h-4 w-4" /> تسجيل الخروج
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
}

function BottomBar() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { userData } = useAuth();

  const items = [
    { title: "الرئيسية", url: "/", icon: Home },
    { title: "الجولات", url: "/rooms", icon: Search },
    { title: "الملفات", url: "/files", icon: FileText },
    { title: "الديني", url: "/islamic", icon: Moon },
    { title: "أنا", url: "/profile", icon: User, avatar: userData?.photoURL },
  ];

  return (
    <nav className="fixed bottom-3 left-3 right-3 z-40 md:hidden">
      <div className="glass-strong flex items-center justify-around rounded-2xl px-2 py-1.5 shadow-gold">
        {items.map((it) => {
          const active = isActive(path, it.url);
          return (
            <Link
              key={it.url}
              to={it.url}
              className={`relative flex flex-col items-center gap-0.5 rounded-xl px-3 py-1.5 transition-all ${
                active ? "text-gold" : "text-muted-foreground"
              }`}
            >
              {it.avatar ? (
                <Avatar className={`h-6 w-6 ${active ? "ring-2 ring-gold" : ""}`}>
                  <AvatarImage src={it.avatar} />
                  <AvatarFallback className="bg-gold/20 text-gold text-[10px]">
                    {userData?.displayName?.[0]}
                  </AvatarFallback>
                </Avatar>
              ) : (
                <it.icon className="h-5 w-5" />
              )}
              <span className="text-[10px] font-bold">{it.title}</span>
              {active && (
                <span className="absolute -top-1 left-1/2 h-1 w-1 -translate-x-1/2 rounded-full bg-gold shadow-glow" />
              )}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

function MobileTopBar() {
  const { userData, logout } = useAuth();
  const { mode, setMode } = useTheme();
  const rank = getRank(userData?.points || 0);

  return (
    <header className="sticky top-0 z-30 md:hidden">
      <div className="glass-subtle flex items-center justify-between px-4 py-3 border-b border-gold/15">
        <Link to="/" className="flex items-center gap-2">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg gradient-gold">
            <Sparkles className="h-4 w-4 text-background" />
          </div>
          <div>
            <div className="text-base font-black text-gradient leading-none">إدراك</div>
          </div>
        </Link>

        <div className="flex items-center gap-1.5">
          <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setMode(mode === "dark" ? "light" : "dark")}>
            {mode === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="flex items-center gap-1.5 rounded-lg border border-gold/20 bg-card/40 px-1.5 py-1">
                <span className="text-[10px] font-bold text-gold">{rank.name}</span>
                <Avatar className="h-6 w-6">
                  <AvatarImage src={userData?.photoURL} />
                  <AvatarFallback className="text-[10px]">{userData?.displayName?.[0]}</AvatarFallback>
                </Avatar>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="glass-strong w-52">
              {NAV_SECONDARY.map((it) => (
                <DropdownMenuItem key={it.url} asChild>
                  <Link to={it.url} className="gap-2"><it.icon className="h-4 w-4" /> {it.title}</Link>
                </DropdownMenuItem>
              ))}
              <DropdownMenuSeparator />
              <DropdownMenuItem onClick={logout} className="gap-2 text-destructive">
                <LogOut className="h-4 w-4" /> تسجيل الخروج
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
}

function CommandPalette({ open, setOpen }: { open: boolean; setOpen: (v: boolean) => void }) {
  const navigate = useNavigate();
  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput placeholder="ابحث عن صفحة أو ميزة..." />
      <CommandList>
        <CommandEmpty>لا توجد نتائج</CommandEmpty>
        <CommandGroup heading="التنقل">
          {NAV_ALL.map((it) => (
            <CommandItem
              key={it.url}
              onSelect={() => { setOpen(false); navigate({ to: it.url }); }}
              className="gap-2"
            >
              <it.icon className="h-4 w-4 text-gold" />
              {it.title}
            </CommandItem>
          ))}
        </CommandGroup>
        <CommandGroup heading="إجراءات">
          <CommandItem onSelect={() => { setOpen(false); navigate({ to: "/rooms/new" }); }} className="gap-2">
            <Plus className="h-4 w-4 text-gold" /> إنشاء جولة جديدة
          </CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  const [cmdOpen, setCmdOpen] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setCmdOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <div className="min-h-screen w-full" dir="rtl">
      <TopNav onOpenCommand={() => setCmdOpen(true)} />
      <MobileTopBar />
      <main className="pb-24 md:pb-6">{children}</main>
      <BottomBar />
      <CommandPalette open={cmdOpen} setOpen={setCmdOpen} />
    </div>
  );
}
