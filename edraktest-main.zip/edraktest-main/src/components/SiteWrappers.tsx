import { useEffect, useState } from "react";
import { doc, onSnapshot } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { Wrench, X, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

const DUA_KEY = "edrak_dua_disabled";
const DUA_SHOWN_KEY = "edrak_dua_shown_today";

export function MaintenanceGate({ children }: { children: React.ReactNode }) {
  const [maintenance, setMaintenance] = useState<{ on: boolean; msg: string } | null>(null);

  useEffect(() => {
    const unsub = onSnapshot(doc(db, "site", "config"), (snap) => {
      const d = snap.data();
      setMaintenance({ on: !!d?.maintenance, msg: d?.maintenanceMessage || "نعمل على تحديث الموقع، عُد قريباً" });
    }, () => setMaintenance({ on: false, msg: "" }));
    return unsub;
  }, []);

  if (maintenance?.on) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background p-4" dir="rtl">
        <div className="max-w-md rounded-2xl border bg-card p-8 text-center shadow-soft">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl gradient-primary shadow-glow">
            <Wrench className="h-8 w-8 text-white" />
          </div>
          <h1 className="mt-4 text-2xl font-black">الموقع تحت الصيانة</h1>
          <p className="mt-2 text-sm text-muted-foreground">{maintenance.msg}</p>
        </div>
      </div>
    );
  }
  return <>{children}</>;
}

export function DuaPopup() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (localStorage.getItem(DUA_KEY) === "1") return;
    const today = new Date().toDateString();
    if (sessionStorage.getItem(DUA_SHOWN_KEY) === today) return;
    sessionStorage.setItem(DUA_SHOWN_KEY, today);
    const t = setTimeout(() => setShow(true), 800);
    return () => clearTimeout(t);
  }, []);

  if (!show) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4 backdrop-blur-sm" onClick={() => setShow(false)}>
      <div className="relative w-full max-w-md rounded-2xl border bg-card p-6 shadow-glow" onClick={(e) => e.stopPropagation()}>
        <button onClick={() => setShow(false)} className="absolute left-3 top-3 rounded-full p-1 hover:bg-accent">
          <X className="h-4 w-4" />
        </button>
        <div className="text-center">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl gradient-primary">
            <Sparkles className="h-6 w-6 text-white" />
          </div>
          <h2 className="mt-3 text-lg font-black">دعاء قبل الدراسة</h2>
          <p className="mt-3 text-base leading-relaxed text-foreground">
            «اللّهمَّ إنّي أسألُك فهمَ النّبيين، وحفظَ المُرسَلين، والملائكةِ المقرّبين، اللّهم اجعل ألسنتنا عامرةً بذكرك، وقلوبَنا بخشيتك، وأسرارَنا بطاعتك، إنّك على كلِّ شيءٍ قديرٌ».
          </p>
          <div className="mt-4 flex gap-2">
            <Button variant="outline" className="flex-1" onClick={() => { localStorage.setItem(DUA_KEY, "1"); setShow(false); }}>
              عدم الإظهار مجدداً
            </Button>
            <Button className="flex-1" onClick={() => setShow(false)}>آمين</Button>
          </div>
        </div>
      </div>
    </div>
  );
}
